package com.beyontec.mol.resource;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.fileUpload;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.InputStream;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;

import com.beyontec.mol.service.ClaimService;

public class ClaimResourceTest extends BaseResourceTest {

	@Autowired
	ClaimService claimService;

	@Autowired
	private ResourceLoader resourceLoader;

	@Test
	public void testCreateClaim() throws Exception {
		 
		 String claimInfo = "{\r\n" + 
		 		"	\"complaintNumber\": \"CL/3341/12883/2017\",\r\n" + 
		 		"	\"employerName\": \"dhoni\",\r\n" + 
		 		"	\"employerLicenseNo\": \"32366\",\r\n" + 
		 		"	\"claimLaunchDate\": \"18-09-2018\",\r\n" + 
		 		"	\"emiratesId\": \"784-2001-123456-1\",\r\n" + 
		 		"	\"visaReferenceNo\": \"21312\",\r\n" + 
		 		"	\"claimReason\": \"reason1\",\r\n" + 
		 		"	\"claimReason2\":\"reason2\",\r\n" + 
		 		"	\"claimDescription\": \"nothing5\",\r\n" + 
		 		"	\"claimPaymentType\":\"Ticket\",\r\n" + 
		 		"	\"payeeType\":\"W\",\r\n" + 
		 		"	\"paymentAmount\":\"2000\",\r\n" + 
		 		"	\"payeePhoneNumber\":\"8746434455\",\r\n" + 
		 		"	\"payeeEmail\":\"beyontec@gmail.com\",\r\n" + 
		 		"	\"groupId\":\"grd1\",\r\n" + 
		 		"	\"remarks\":\"remarks1\"\r\n" + 
		 		"}";
		 
		 
		 InputStream in1 = resourceLoader.getResource("classpath:sample.pdf").getInputStream();
	        MockMultipartFile multipartFile1 = new MockMultipartFile("documents", "sample.pdf",
	                MediaType.APPLICATION_PDF_VALUE, in1);
	        
	        InputStream in2 = resourceLoader.getResource("classpath:sample.jpg").getInputStream();
	        MockMultipartFile multipartFile2 = new MockMultipartFile("documents", "sample.jpg",
	                MediaType.IMAGE_JPEG_VALUE, in2);
	        
		            mockMvc.perform(fileUpload("/api/claims/create")
	                .file(multipartFile1)
	                .file(multipartFile2)
	                .param("claimInfo", claimInfo)
	                .headers(getAdminAuthHeaders()))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$.emiratesId", containsString("784-2001-123456-1")));
	 }
	 
}
