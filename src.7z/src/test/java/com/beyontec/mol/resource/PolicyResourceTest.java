package com.beyontec.mol.resource;

import static org.junit.Assert.assertEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.beyontec.mol.modal.PagedResult;
import com.beyontec.mol.modal.PaginatedRequest;
import com.beyontec.mol.modal.Policy;
import com.beyontec.mol.modal.PolicySearchCriteria;
import com.beyontec.mol.service.PolicyService;

public class PolicyResourceTest extends BaseResourceTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private PolicyService policyService;
	

	@Test
	public void testPolicyCriteriaSearch() throws Exception {

		PolicySearchCriteria policySearchCriteria = new PolicySearchCriteria();

		policySearchCriteria.setCustomerName("mol");
		policySearchCriteria.setMasterPolicyNo("12563544");

		Policy policy = new Policy();

		policy.setCustomerName("mol");
		policy.setMasterPolicyNo("12563544");
		policy.setProductType("W");

		Policy policy1 = new Policy();

		policy.setCustomerName("mol");
		policy.setMasterPolicyNo("89562358");
		policy.setProductType("A");

		List<Policy> poList = new ArrayList<Policy>();

		poList.add(policy);
		poList.add(policy1);

		//PolicyDTO policyDTO = new PolicyDTO(poList, 1);
		PaginatedRequest pageReq= new PaginatedRequest();
		pageReq.setOffset(1);
		
		PagedResult<Policy> pagedResult = new PagedResult<Policy>(poList, new Long(1));

		String inputJson = "{\r\n" + "	 \"selectPolicyType\":\"\",\r\n" + "	\"masterPolicyNo\":\"12563544\",\r\n"
				+ "	\"customerName\":\"\",\r\n" + "	\"productType\":\"\"\r\n" + "\r\n" + "}";

		System.out.println("input:" + inputJson);
		
		
		Mockito.when(policyService.policyCriteriaSearch(policySearchCriteria, pageReq)).thenReturn(pagedResult);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/searchPolicy").headers(getAdminAuthHeaders())
				.accept(MediaType.APPLICATION_JSON).content(inputJson).param("offset", "1").param("limit", "10")
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.OK.value(), response.getStatus());

		// assertEquals("http://localhost:8081/mol/api/searchPolicy?offset=1",response.getHeader(HttpHeaders.LOCATION));

	}
	 


}
