package com.beyontec.mol.resource;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.beyontec.mol.entity.User;
import com.beyontec.mol.modal.Password;
import com.beyontec.mol.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserResource extends BaseResource {

    @Autowired
    private UserService userService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> getAllUsers() {

        List<User> users = userService.findAll();
        return ResponseEntity.ok(users);
    }

    @PutMapping(value = "")
    public ResponseEntity<?> createUser(@Valid @RequestBody User user, Errors errors) {

        if (errors.hasErrors()) {
            return ResponseEntity.badRequest().body(getErrorMessage(errors));
        }
        userService.createUser(user);
        return ResponseEntity.ok(user);
    }

    @PutMapping(value = "/resetPassword")
    public ResponseEntity<?> resetPassword(@Valid @RequestBody Password password) {

        User user = userService.resetPassword(password);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<?> updateUser(@PathVariable("id") Long id, @Valid @RequestBody User user, Errors errors) {

        if (errors.hasErrors()) {
            return ResponseEntity.badRequest().body(getErrorMessage(errors));
        }
        userService.updateUser(user);
        return ResponseEntity.ok(user);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<?> getUserById(@PathVariable("id") Long id) {

        User user = userService.findUserById(id);
        return ResponseEntity.ok(user);
    }

    @DeleteMapping(value = "/{id}")
    public void delete(@PathVariable("id") String id) {
        userService.deleteUser(id);
    }
}
