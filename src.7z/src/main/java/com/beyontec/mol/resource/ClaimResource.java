package com.beyontec.mol.resource;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.beyontec.mol.entity.Claim;
import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.modal.ClaimDTO;
import com.beyontec.mol.modal.ClaimListingDTO;
import com.beyontec.mol.modal.ClaimRegistartionListingDTO;
import com.beyontec.mol.modal.ClaimRegistrationResponse;
import com.beyontec.mol.modal.ClaimsSearchCriteria;
import com.beyontec.mol.modal.PaginatedRequest;
import com.beyontec.mol.modal.UpdateClaimDTO;
import com.beyontec.mol.service.ClaimService;
import com.beyontec.mol.util.CustomDateDeserializer;
import com.beyontec.mol.util.CustomDateSerializer;
import com.beyontec.mol.util.ExcelExporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

@RestController
@RequestMapping("/api/claims")
public class ClaimResource {
	
	@Value("${date.format}")
	private String dateFormat;

	@Autowired
	private ClaimService claimService;

	@GetMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getClaims(@RequestParam("fromDate") Date fromDate, @RequestParam("toDate") Date toDate,
			@RequestParam("offset") int offset) {

		List<Claim> claims = claimService.getClaims(fromDate, toDate, offset);
		return ResponseEntity.ok(claims);
	}

	@PostMapping(value = "/export")
	public ResponseEntity<?> exportToExcel(@RequestBody List<String> ids) throws IOException {
		List<ClaimListingDTO> claims = claimService.findAllRecordsByFnolIds(ids);
		byte[] excelByteArray = ExcelExporter.convertJavaToExcel(claims);

		return ResponseEntity.ok().contentLength(excelByteArray.length)
				.header("Content-Disposition", "attachment; filename=" + "cliams.xlsx")
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
				.body(new ByteArrayResource(excelByteArray));
	}

	@PostMapping(value = "/search")
	public ResponseEntity<?> searchClaims(@RequestBody ClaimsSearchCriteria claimsSearchCriteria,
			PaginatedRequest paginatedRequest) {

		Date fromDate = claimsSearchCriteria.getFromDate();
		Date toDate = claimsSearchCriteria.getToDate();
		if (fromDate != null && toDate != null && fromDate.after(toDate)) {
			throw new ApplicationException(ErrorCode.INVALID_DATES);
		}
		return ResponseEntity.ok(claimService.findAllClaimsBySearchCriteria(claimsSearchCriteria, paginatedRequest));
	}

	@GetMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE, value = "/getclaim")
	public ResponseEntity<?> getClaimById(@RequestParam("claimNo") String claimId, HttpServletRequest request) throws ParseException {
		ClaimRegistartionListingDTO claimRegistartionListing = claimService.getClaimRegistartionListingDTO(claimId, request.getLocale());
		return ResponseEntity.ok(claimRegistartionListing);
	}

	@PostMapping(value = "/create")
	public ResponseEntity<?> createClaim(@RequestPart("claimInfo") String claimInfo,
			@RequestPart("documents") MultipartFile[] documents, HttpServletRequest request) throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		SimpleModule module = new SimpleModule();
		module.addDeserializer(Date.class, new CustomDateDeserializer(dateFormat));
		mapper.registerModule(module);
		ClaimDTO claimDTO = mapper.readValue(claimInfo, ClaimDTO.class);

		Map<String, Object> map = claimService.createClaim(claimDTO, documents, request.getRemoteAddr(),
				request.getLocale(), request.getHeader(HttpHeaders.AUTHORIZATION));
		ClaimRegistrationResponse claimRegistrationResponse = (ClaimRegistrationResponse) map.get("claimResponse");
		if (claimRegistrationResponse.getErrorId() != null) {
			return ResponseEntity.badRequest().body(claimRegistrationResponse);
		}

		Claim claim = (Claim) map.get("claim");
		claimService.storeClaim(claim);
		return ResponseEntity.ok(claimRegistrationResponse);
	}

	@PostMapping(value = "/update")
	public ResponseEntity<?> updateClaim(@RequestPart("claimInfo") String claimInfo,
			@RequestPart("documents") MultipartFile[] documents, HttpServletRequest request) throws Exception {

		ObjectMapper mapper = new ObjectMapper();
		UpdateClaimDTO updateClaimDTO = mapper.readValue(claimInfo, UpdateClaimDTO.class);

		return ResponseEntity.ok(claimService.updateClaim(updateClaimDTO, documents, request.getLocale(),
				request.getHeader(HttpHeaders.AUTHORIZATION)));
	}

	@GetMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE, value = "/getClaimCriteriaDetails")
	public ResponseEntity<?> getClaimCriteriaDetails(@RequestParam("companyId") String companyId) {
		return ResponseEntity.ok(claimService.getSearchCriteriaValues(companyId));
	}
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE, value = "/getPaymentDetails")
	public ResponseEntity<?> getPaymentDetails(@RequestParam("claimNo") String claimNo) {
		return ResponseEntity.ok(claimService.getPayemntListingDTO(claimNo));
	}
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE, value = "/getClaimActions")
	public ResponseEntity<?> getClaimActions(@RequestParam("claimNo") String claimId, HttpServletRequest request){
		List<String> actions = claimService.getActions(claimId, request.getLocale());
		return ResponseEntity.ok(actions);
	}
}