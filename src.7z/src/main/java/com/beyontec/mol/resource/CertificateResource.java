package com.beyontec.mol.resource;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.beyontec.mol.entity.PolicyHistory;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.exception.ValidationException;
import com.beyontec.mol.modal.CancelCertificateDTO;
import com.beyontec.mol.modal.CertificateDTO;
import com.beyontec.mol.modal.CertificateResponseDTO;
import com.beyontec.mol.modal.ResponseDTO;
import com.beyontec.mol.service.CertificateService;
import com.beyontec.mol.util.AppConstants;

@RestController
@RequestMapping("/api/certificate")
public class CertificateResource {

	@Autowired
	private CertificateService certificateService;

	@SuppressWarnings("unchecked")
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<CertificateResponseDTO> generateCertificate(@Valid @RequestBody CertificateDTO certificateDTO,
                                                                      BindingResult bindingResult,
                                                                      WebRequest request) throws Exception {
        PolicyHistory masterPolicy = certificateService.getMasterPolicy(certificateDTO);

        Map<String, Object> result = certificateService.createCertificate(certificateDTO,
                                                                          masterPolicy,
                                                                          bindingResult.hasErrors(),
                                                                          request.getHeader(HttpHeaders.AUTHORIZATION));

		if (result.get(AppConstants.ERRORS) != null) {
			throw new ValidationException((Map<ErrorCode, Object[]>) result.get(AppConstants.ERRORS));
		}

        certificateService.addCertificateEntries(certificateDTO,
                                                 result.get(AppConstants.CERTIFICATE_NO).toString(),
                                                 masterPolicy);
		return ResponseEntity.ok(new CertificateResponseDTO(result.get(AppConstants.CERTIFICATE_NO).toString()));
	}

	@RequestMapping(value = "/cancel", method = RequestMethod.POST)
	public ResponseEntity<ResponseDTO> cancelCertificate(@Valid @RequestBody CancelCertificateDTO cancelCertificateDTO,
			BindingResult bindingResult) throws Exception {

		boolean result = certificateService.cancelCertificate(cancelCertificateDTO, bindingResult.hasErrors());
		certificateService.cancelCertificateEntries(cancelCertificateDTO);
		return ResponseEntity.ok(new ResponseDTO(result));
	}
}
