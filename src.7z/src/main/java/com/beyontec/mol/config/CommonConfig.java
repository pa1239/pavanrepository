package com.beyontec.mol.config;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.beyontec.mol.entity.Company;
import com.beyontec.mol.entity.UdsIdDefinition;
import com.beyontec.mol.repository.CompanyRepository;
import com.beyontec.mol.repository.UdsIdDefinitionRepository;
import com.beyontec.mol.service.BaseService;

@Component
public class CommonConfig extends BaseService implements InitializingBean {
    // Date configs
    @Value("${date.format}") private String dateFormat;
	public static SimpleDateFormat DATE_FORMAT;

    // Company configs
    public static Company COMPANY;
    public static String COMPANY_ID;

    // UDS ID Definition configs
    private static Map<String, Map<String, UdsIdDefinition>> udsIdTypeIdIndex = new HashMap<>();

    // Defaults
    public static final String FLAG_NO = "N";
    public static final String RECORD_TYPE_N = "N";
    public static final String RECORD_TYPE_I = "I";
    public static final Long DEFAULT_VERSION_NUMBER = 0L;
    public static final String BTYPE_POLICY = "P";
    public static final String UDS_ID_DEF_TYPE_RISK_TYPE = "MAP_ULR_RISK_TYP";

    public static final String UDS_ID_DEF_TYPE_DEFAULT_DATA = "DFLT_DATA";
    public static final String UDS_ID_DEF_ID_DEFAULT_CUST_ID_TYPE1 = "DFLT_UCD_ID_TYP1";
    public static final String UDS_ID_DEF_ID_DEFAULT_CUST_ID_TYPE2 = "DFLT_UCD_ID_TYP2";
    public static final String UDS_ID_DEF_ID_DEFAULT_CUST_CATEGORY_ID = "DFLT_UCD_CUST_CATG_ID";

    public static final String UDS_ID_DEF_ID_DEFAULT_CREATED_USER = "DFLT_ULM_CRU";
    public static final String PREFERRED_LANG_EN = "en";

    @Autowired private CompanyRepository companyRepo;
    @Autowired private UdsIdDefinitionRepository udsIdDefinitionRepo;

	@Override
	public void afterPropertiesSet() throws Exception {
		loadDateConfigs();
        loadCompanyConfigs();
        loadUdsIdDefinitionConfigs();
	}

    private void loadCompanyConfigs() {
        List<Company> companies = invokeRepo(() -> companyRepo.findAll(), "companyRepo.findAll()");

        // Only one company will be present in the DB and the table will not be empty
        COMPANY = companies.get(0);
        COMPANY_ID = COMPANY.getId();
    }

    private void loadDateConfigs() {
        DATE_FORMAT = new SimpleDateFormat(dateFormat);
		DATE_FORMAT.setLenient(false);
    }

    private void loadUdsIdDefinitionConfigs() {
        List<UdsIdDefinition> udsIdDefinitions = invokeRepo(() -> udsIdDefinitionRepo.findByCompanyId(COMPANY_ID),
                                                            "udsIdDefinitionRepo.findByCompanyId(COMPANY_ID)");

        udsIdDefinitions.forEach(udsIdDefinition -> {
            String idType = udsIdDefinition.getUID_ID_TYP();
            Map<String, UdsIdDefinition> idIndex = udsIdTypeIdIndex.get(idType);

            if (idIndex == null) {
                idIndex = new HashMap<>();
                udsIdTypeIdIndex.put(idType, idIndex);
            }
            idIndex.put(udsIdDefinition.getUID_ID(), udsIdDefinition);
        });
    }

    // @formatter:off
    public static Map<String, UdsIdDefinition> getUdsIdDefinition(String idType) { return udsIdTypeIdIndex.get(idType); }
    public static UdsIdDefinition getUdsIdDefinition(String idType, String id)   { return getUdsIdDefinition(idType).get(id); }
    public static String getUdsIdDefinitionValue(String idType, String id)       { return getUdsIdDefinition(idType, id).getUID_VALUE(); }

    public static String getRiskType(String udsIdDefId) { return getUdsIdDefinitionValue(CommonConfig.UDS_ID_DEF_TYPE_RISK_TYPE, udsIdDefId); }
    // @formatter:on

}
