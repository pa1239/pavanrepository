package com.beyontec.mol.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.beyontec.mol.entity.CertificateDetails;
import com.beyontec.mol.entity.Claim;
import com.beyontec.mol.entity.ClaimAdditionalDetails;
import com.beyontec.mol.entity.ClaimHistoryEstimation;
import com.beyontec.mol.entity.ClaimTransactionClaim;
import com.beyontec.mol.entity.ClaimTransactionClaimantDetails;
import com.beyontec.mol.entity.ClaimTransactionEstimation;
import com.beyontec.mol.entity.ClaimTransactionFNOL;
import com.beyontec.mol.entity.ClaimTransactionRisk;
import com.beyontec.mol.entity.ClaimWorkingEstimation;
import com.beyontec.mol.entity.UploadDocumentEntity;
import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.exception.ValidationException;
import com.beyontec.mol.modal.ClaimDTO;
import com.beyontec.mol.modal.ClaimDetails;
import com.beyontec.mol.modal.ClaimFieldListingDTO;
import com.beyontec.mol.modal.ClaimListingDTO;
import com.beyontec.mol.modal.ClaimRegistartionListingDTO;
import com.beyontec.mol.modal.ClaimRegistrationResponse;
import com.beyontec.mol.modal.ClaimsSearchCriteria;

import com.beyontec.mol.modal.GeneralDetails;
import com.beyontec.mol.modal.LossDetails;
import com.beyontec.mol.modal.DMSDocumentMetadata;
import com.beyontec.mol.modal.DMSDocumentMetadataDTO;
import com.beyontec.mol.modal.PagedResult;
import com.beyontec.mol.modal.PaginatedRequest;
import com.beyontec.mol.modal.PaymentEstimateDetails;
import com.beyontec.mol.modal.PaymentListingDTO;
import com.beyontec.mol.modal.PaymentDetails;
import com.beyontec.mol.modal.PolicyRisk;
import com.beyontec.mol.modal.PriorClaims;
import com.beyontec.mol.modal.ResponseDTO;
import com.beyontec.mol.modal.SponsorDetails;
import com.beyontec.mol.modal.UpdateClaimDTO;
import com.beyontec.mol.modal.WorkerInfo;
import com.beyontec.mol.repository.CertificateDetailsRepository;
import com.beyontec.mol.repository.ClaimAdditionalDeatilsRepository;
import com.beyontec.mol.repository.ClaimDAO;
import com.beyontec.mol.repository.ClaimEstimationHistoryRepository;
import com.beyontec.mol.repository.ClaimFnolDetailsRepository;
import com.beyontec.mol.repository.ClaimTranasctionPayment;
import com.beyontec.mol.repository.ClaimTransactionClaimDetailsRepository;
import com.beyontec.mol.repository.ClaimTransactionEstimationRepository;
import com.beyontec.mol.repository.ClaimTransactionRiskRepository;
import com.beyontec.mol.repository.ClaimWorkingDetailsRepository;
import com.beyontec.mol.repository.ClaimsRepository;
import com.beyontec.mol.repository.InsuredDetailsDataRepository;
import com.beyontec.mol.repository.PolicyRepository;
import com.beyontec.mol.repository.UploadDocumentRepository;
import com.beyontec.mol.util.ClaimRegistrationConstants;
import com.beyontec.mol.util.DMSConstants;

@Service
public class ClaimService {

	ModelMapper modelMapper = new ModelMapper();
	ClaimTransactionFNOL fnolData = null;
	PolicyRisk policyData = null;
	List<Object[]> policyDatalist = null;
	int cliamFnolSgsId;
	String companyId;
	String createdUser;
	ClaimWorkingEstimation workingEstm;

	private final MessageSource messageSource;

	@Autowired
	public ClaimService(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	@Autowired
	private ClaimsRepository claimsRepository;

	@Autowired
	private ClaimAdditionalDeatilsRepository claimAdditionalDeatilsRepository;

	@Autowired
	private ClaimDAO claimDAO;

	@Autowired
	private PolicyRepository policyRepository;

	@Autowired
	private ClaimFnolDetailsRepository claimFnolDetailsRepository;

	@Autowired
	private ClaimTransactionClaimDetailsRepository claimDetailsRepository;

	@Autowired
	private InsuredDetailsDataRepository insuredDetailsDataRepository;

	@Autowired
	private ClaimTransactionRiskRepository claimTransactionRiskRepository;

	@Autowired
	private ClaimWorkingDetailsRepository claimWorkingDetailsRepository;

	@Autowired
	private ClaimTransactionEstimationRepository claimTransactionEstimationRepository;

	@Autowired
	private ClaimEstimationHistoryRepository claimEstimationHistoryRepository;

	@Autowired
	private UploadDocumentRepository uploadDocumentRepository;

	@Autowired
	private CertificateDetailsRepository certificateDetailsRepository;

	@Autowired
	private DMSService dmsService;

	@Autowired
	private ClaimTranasctionPayment claimTransactionPayment;

	@Value("${claim.fileTypes}")
	private String claimFileTypes;

	@Value("${date.format}")
	private String dateFormat;

	@Transactional(readOnly = true)
	public List<Claim> getClaims(Date fromDate, Date toDate, int offset) {

		return new ArrayList<Claim>();
//        return claimsRepository.findAllByClaimLaunchDateBetween(fromDate, toDate,
//                new PageRequest(offset, recordsPerPage));
	}

	@Transactional(readOnly = true)
	public List<ClaimListingDTO> findAllRecordsByFnolIds(List<String> ids) {
		return claimDAO.getClaimByClaimId(ids);
	}

	@Transactional(readOnly = true)
	public PagedResult<ClaimListingDTO> findAllClaimsBySearchCriteria(ClaimsSearchCriteria claimsSearchCriteria,
			PaginatedRequest paginatedRequest) {

		List<ClaimListingDTO> claims = claimDAO.searchClaims(claimsSearchCriteria, paginatedRequest);
		return new PagedResult<ClaimListingDTO>(claims, claimDAO.getClaimsCount(claimsSearchCriteria));
	}

	@Transactional(readOnly = true)
	public ClaimRegistartionListingDTO getClaimRegistartionListingDTO(String claimNo, Locale locale)
			throws ParseException {

		String sponsorName = null;
		String TradeLiceNo = null;
		String establishCliassification = null;
		String industry = null;
		String certificateNo = null;

		ClaimRegistartionListingDTO claimRegistartionListingDTO = new ClaimRegistartionListingDTO();
		ClaimTransactionClaim ctdsLevelC = claimDetailsRepository.findByClaimNo(claimNo);
		certificateNo = claimFnolDetailsRepository.getCertificateNo(ctdsLevelC.getFnolSgsId());
		Claim claim = claimsRepository.findByComplaintNumber(claimNo);
		String insuredId = claimFnolDetailsRepository.getInsuredId(ctdsLevelC.getFnolSgsId());
		List<Object[]> policyFromAndToDate = claimFnolDetailsRepository
				.getPolicyFromAndToDate(ctdsLevelC.getFnolSgsId());

		List<Object[]> udsCustomerDtlsList = claimsRepository.getUdsCustomer(insuredId);
		if (!StringUtils.isEmpty(udsCustomerDtlsList)) {
			Object[] udsCustomerDtls = udsCustomerDtlsList.get(0);

			if (!StringUtils.isEmpty(udsCustomerDtls)) {

				if (!StringUtils.isEmpty(udsCustomerDtls[0])) {
					sponsorName = udsCustomerDtls[0].toString();
				}
				if (!StringUtils.isEmpty(udsCustomerDtls[1])) {
					TradeLiceNo = udsCustomerDtls[1].toString();
				}
				if (!StringUtils.isEmpty(udsCustomerDtls[2])) {
					establishCliassification = udsCustomerDtls[2].toString();
				}
				if (!StringUtils.isEmpty(udsCustomerDtls[3])) {
					industry = udsCustomerDtls[3].toString();
				}
			}
		}

		CertificateDetails certificate = certificateDetailsRepository.findByEmiratesIdAndErrType(claim.getEmiratesId(),
				null);
		String employeeName = insuredDetailsDataRepository.getInsuredName(ctdsLevelC.getFnolSgsId());

		ClaimDetails claimDetails = new ClaimDetails();

		if (!StringUtils.isEmpty(ctdsLevelC.getPolicyNo())) {
			claimDetails.setCertificateNo(ctdsLevelC.getPolicyNo());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getClaimNo())) {
			claimDetails.setClaimNo(ctdsLevelC.getClaimNo());
		}
		if (!StringUtils.isEmpty(claim.getClaimStatus())) {
			claimDetails.setClaimStatus(ctdsLevelC.getClaimStatus());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getLossDate())) {
			claimDetails.setLossDate(ctdsLevelC.getLossDate());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getCreatedDate())) {
			claimDetails.setCreatedDate(ctdsLevelC.getCreatedDate());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getProductId())) {
			/*
			 * int productId = Integer.parseInt(ctdsLevelC.getProductId()); String
			 * productName = claimsRepository.getDescription(productId);
			 * claimDetails.setProductName(productName);
			 */
		}
		if (!StringUtils.isEmpty(employeeName)) {
			claimDetails.setInsuredName(employeeName);
		}

		if (!StringUtils.isEmpty(sponsorName)) {
			claimDetails.setSponsorName(sponsorName);

		}
		claimRegistartionListingDTO.setClaimDetails(claimDetails);

		GeneralDetails generalDetails = new GeneralDetails();
		if (!StringUtils.isEmpty(certificate)) {
			if (!StringUtils.isEmpty(certificate.getMasterPolicyNo())) {
				generalDetails.setMasterPolicyNo(certificate.getMasterPolicyNo());
			}
			if (!StringUtils.isEmpty(ctdsLevelC.getPolicyNo())) {
				generalDetails.setCertificateNo(ctdsLevelC.getPolicyNo());
			}
			if (policyFromAndToDate != null && policyFromAndToDate.size() > 0) {
				Object[] obj = policyFromAndToDate.get(0);

				Date fromDate = (Date) obj[0];
				SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				Date d = f.parse(fromDate.toString());
				SimpleDateFormat f2 = new SimpleDateFormat(dateFormat);

				Date toDate = (Date) obj[1];
				Date d1 = f.parse(toDate.toString());
				SimpleDateFormat f3 = new SimpleDateFormat(dateFormat);

				String certificatePeriod = f2.format(d) + " " + getErrorMessage(ErrorCode.TO, locale) + " "
						+ f3.format(d1);
				generalDetails.setCertificatePeriod(certificatePeriod);
			}
			if (!StringUtils.isEmpty(ctdsLevelC.getProductId())) {
				generalDetails.setProductName(ctdsLevelC.getProductId());
			}
		}
		claimRegistartionListingDTO.setGeneralDetails(generalDetails);

		SponsorDetails sponsorDetails = new SponsorDetails();
		if (!StringUtils.isEmpty(certificate)) {
			if (sponsorName != null) {
				sponsorDetails.setSponsorName(sponsorName);
			}
			if (!StringUtils.isEmpty(TradeLiceNo)) {
				sponsorDetails.setTradeLicenseNo(TradeLiceNo);
			}
			if (!StringUtils.isEmpty(establishCliassification)) {
				sponsorDetails.setEstabClassification(establishCliassification);
			}
			if (!StringUtils.isEmpty(industry)) {
				sponsorDetails.setIndustry(industry);
			}
		}
		claimRegistartionListingDTO.setSponsorDetails(sponsorDetails);

		WorkerInfo workerInfo = new WorkerInfo();
		List<Object[]> workerInfoList = claimsRepository.getWorkerInformation(claim.getEmiratesId());
		if (workerInfo != null && workerInfoList.size() > 0) {
			Object[] obj = workerInfoList.get(0);
			if (obj[0] != null) {
				workerInfo.setEmiratesId(obj[0].toString());
			}
			if (obj[1] != null) {
				workerInfo.setName(obj[1].toString());
			}
			if (obj[2] != null) {
				workerInfo.setDob(new Date(((Timestamp) obj[2]).getTime()));
			}
			if (obj[3] != null) {
				workerInfo.setGender(obj[3].toString());
			}
			if (obj[4] != null) {
				workerInfo.setPassportNo(obj[4].toString());
			}
			if (obj[5] != null) {
				workerInfo.setEmployeeCategory(obj[5].toString());
			}
			if (obj[6] != null) {
				workerInfo.setDesignation(obj[6].toString());
			}
		}
		claimRegistartionListingDTO.setWorkerInfo(workerInfo);

		LossDetails lossDetails = new LossDetails();
		if (!StringUtils.isEmpty(ctdsLevelC.getCreatedDate())) {
			lossDetails.setCreatedDate(ctdsLevelC.getCreatedDate());
		}
		if (!StringUtils.isEmpty(claim.getClaimLaunchDate())) {
			lossDetails.setLossDate(ctdsLevelC.getLossDate());
		}
		if (!StringUtils.isEmpty(claim.getClaimReason())) {
			lossDetails.setClaimReason(ctdsLevelC.getClaimReason());
		}
		if (!StringUtils.isEmpty(claimFnolDetailsRepository.getClaimDescription(claimNo))) {
			lossDetails.setClaimDescription(claimFnolDetailsRepository.getClaimDescription(claimNo));
		}
		if (!StringUtils.isEmpty(claimTransactionEstimationRepository.getPaymentType(cliamFnolSgsId))) {
			String id = claimTransactionEstimationRepository.getPaymentType(cliamFnolSgsId);
			lossDetails.setPaymentType(claimsRepository.getDescription(id));
		}
		claimRegistartionListingDTO.setLossDetails(lossDetails);

		List<PriorClaims> priorClaimslist = new ArrayList<>();

		List<String> priorClaimNolist = claimFnolDetailsRepository.getPriorClaimNo(certificateNo);

		for (String priorClaimNo : priorClaimNolist) {
			PriorClaims priorClaim = new PriorClaims();
			priorClaim.setClaimNo(priorClaimNo);
			priorClaimslist.add(priorClaim);
		}

		List<String> priorPaidAmountlist = claimFnolDetailsRepository.getPaidAmount(certificateNo);
		for (int i = 0; i < priorClaimslist.size(); i++) {
			for (String priorPaidAmount : priorPaidAmountlist) {
				PriorClaims priorClaim = priorClaimslist.get(i);
				priorClaim.setPaidamount(priorPaidAmount);
			}
		}

		List<String> priorClaimStatusList = claimFnolDetailsRepository.getStatus(certificateNo);
		for (int i = 0; i < priorClaimslist.size(); i++) {
			for (String priorClaimStatus : priorClaimStatusList) {
				PriorClaims priorClaim = priorClaimslist.get(i);
				priorClaim.setStatus(priorClaimStatus);
			}
		}
		claimRegistartionListingDTO.setPriorClaims(priorClaimslist);

		return claimRegistartionListingDTO;
	}

	@Transactional
	public Map<String, Object> createClaim(ClaimDTO claimDTO, MultipartFile[] documents, String ipAddress,
			Locale locale, String authHeader) throws Exception {

		Map<String, Object> map = new HashMap<>();
		Map<ErrorCode, Object[]> errorDetails = validateCreateClaimRequest(claimDTO, documents);

		Claim claim = modelMapper.map(claimDTO, Claim.class);
		claim.setCompanyId(claimsRepository.getCompanyId());
		claim.setRequestIncomingDate(new Date());
		claim.setRequestIncomingIp(ipAddress);
		claim.setResponseDate(new Date());
		claim.setCodifiedType(ClaimRegistrationConstants.CLAIM_CODIFIED_TYPE);

		CertificateDetails certificateDetails = certificateDetailsRepository
				.findByLabourReferenceNoAndCertificateNumberAndErrType(claimDTO.getVisaReferenceNo(),
						claimDTO.getCertificateNo(), null);
		if (certificateDetails == null) {
			errorDetails.put(ErrorCode.WORKER_NO_POLICY, null);
		}
		if (certificateDetails != null) {
			Date expirtyDate = certificateDetails.getVisaExpirationDate();
			if (expirtyDate.before(new Date())) {
				errorDetails.put(ErrorCode.WORKER_POLICY_EXPIRED, null);
			}
		}

		String payeetype = claimsRepository.getPayeeType(claimDTO.getPayeeType());
		if (StringUtils.isEmpty(payeetype)) {
			errorDetails.put(ErrorCode.INVALID_INPUT_TYPE, new Object[] { "payeeType", claimDTO.getPayeeType() });
		}

		int paymentTypeCount = claimsRepository.getPaymentType(claimDTO.getClaimPaymentType());
		if (paymentTypeCount == 0) {
			errorDetails.put(ErrorCode.INVALID_INPUT_TYPE,
					new Object[] { "claimPaymentType", claimDTO.getClaimPaymentType() });
		}

		if (!errorDetails.containsKey(ErrorCode.CLAIM_LAUNCH_DATE_FORMAT_INVALID)
				&& claim.getClaimLaunchDate().after(new Date())) {
			errorDetails.put(ErrorCode.INVALID_LAUNCH_DATE, null);
		}

		if (errorDetails.size() == 0) {

			claim.setClaimStatus(ClaimRegistrationConstants.CLAIM_REGISTRATION_SUCCESS_STATUS);
			claim.setRespondeId(ClaimRegistrationConstants.CLAIM_REGISTRATION_SUCCESS_RESPOND_ID);
			claim.setResponseMessage(getErrorMessage(ErrorCode.CLAIM_CREATED, locale));
		} else {

			claim.setClaimStatus(ClaimRegistrationConstants.CLAIM_REGISTRATION_ERROR_STATUS);
			claim.setErrorType(ClaimRegistrationConstants.CLAIM_REGISTRATION_ERROR_TYPE);
			claim.setErrorId(ClaimRegistrationConstants.CLAIM_REGISTRATION_ERROR_ID);

			String errorMessage = "";
			for (Map.Entry<ErrorCode, Object[]> entry : errorDetails.entrySet()) {

				if (!StringUtils.isEmpty(errorMessage)) {
					errorMessage += ", ";
				}
				errorMessage += messageSource.getMessage(entry.getKey().getCode(), entry.getValue(), locale);
			}

			claim.setErrorMessage(errorMessage);
			claim.setResponseMessage(getErrorMessage(ErrorCode.CLAIM_CREATION_FAILED, locale));
		}

		claimsRepository.save(claim);

		if (errorDetails.size() == 0 && documents.length > 0) {

			// Generate certificate and upload it to DMS
			DMSDocumentMetadataDTO documentMetadataDTO = new DMSDocumentMetadataDTO(claim.getComplaintNumber(),
					DMSConstants.REF_TYPE_CLAIM);
			List<DMSDocumentMetadata> documentMetadataList = dmsService.uploadDocument(documentMetadataDTO, documents,
					authHeader);

			addDocumentDetails(claim, documentMetadataList);
		}

		map.put("claimResponse", modelMapper.map(claim, ClaimRegistrationResponse.class));
		map.put("claim", claim);

		return map;
	}

	@Transactional
	public ResponseDTO updateClaim(UpdateClaimDTO updateClaimDTO, MultipartFile[] documents, Locale locale,
			String authHeader) throws Exception {

		Map<ErrorCode, Object[]> errorDetails = validateUpdateClaimRequest(updateClaimDTO, documents);

		if (errorDetails.size() > 0) {
			throw new ValidationException(errorDetails);
		}

		Claim claim = claimsRepository.findByComplaintNumberAndErrorType(updateClaimDTO.getComplaintNumber(), null);

		List<DMSDocumentMetadata> documentMetadataList = null;
		if (documents.length > 0) {

			DMSDocumentMetadataDTO documentMetadataDTO = new DMSDocumentMetadataDTO(claim.getComplaintNumber(),
					DMSConstants.REF_TYPE_CLAIM);
			documentMetadataList = dmsService.uploadDocument(documentMetadataDTO, documents, authHeader);
			addDocumentDetails(claim, documentMetadataList);
		}

		addNotes(claim, updateClaimDTO.getNotes());

		return new ResponseDTO(true);
	}

	private Map<ErrorCode, Object[]> validateCreateClaimRequest(ClaimDTO claimDTO, MultipartFile[] documents) {

		Map<ErrorCode, Object[]> errorDetails = new HashMap<>();

		if (StringUtils.isEmpty(claimDTO.getClaimDescription()) || StringUtils.isEmpty(claimDTO.getClaimPaymentType())
				|| StringUtils.isEmpty(claimDTO.getClaimReason()) || StringUtils.isEmpty(claimDTO.getComplaintNumber())
				|| StringUtils.isEmpty(claimDTO.getEmiratesId()) || StringUtils.isEmpty(claimDTO.getEmployerLicenseNo())
				|| StringUtils.isEmpty(claimDTO.getEmployerName()) || StringUtils.isEmpty(claimDTO.getPayeeEmail())
				|| StringUtils.isEmpty(claimDTO.getPayeePhoneNumber()) || StringUtils.isEmpty(claimDTO.getPayeeType())
				|| StringUtils.isEmpty(claimDTO.getPaymentAmount())
				|| StringUtils.isEmpty(claimDTO.getVisaReferenceNo())
				|| StringUtils.isEmpty(claimDTO.getCertificateNo())) {
			errorDetails.put(ErrorCode.EMPTY_MANDATORY_FIELD_CLAIM, null);
		}

		if (claimDTO.getClaimLaunchDate() == null) {
			errorDetails.put(ErrorCode.CLAIM_LAUNCH_DATE_FORMAT_INVALID, new Object[] { dateFormat });
		}

		Claim claim = claimsRepository.findByComplaintNumberAndErrorType(claimDTO.getComplaintNumber(), null);
		if (claim != null) {
			errorDetails.put(ErrorCode.ALREADY_CREATED_CLAIM, null);
		}

		/*
		 * Policy claimPolicy = null; ClaimTransactionFNOL claimFnol =
		 * claimFnolDetailsRepository.findByFnolRefNo(claimInfoDTO.getClaimInfo().
		 * getComplaintNumber()); String policyNo = claimFnol.getPolicyNo(); if
		 * (claimPolicy == null) { errorCode = ErrorCode.WORKER_NO_POLICY; }
		 */
		ClaimTransactionFNOL fnol = claimFnolDetailsRepository.findByFnolRefNo(claimDTO.getEmiratesId());
		if (fnol != null) {
			if (fnol.getCLF_FNOL_TYP().equals(ClaimRegistrationConstants.CLAIM_POLICY_REPATRIATION)) {
				errorDetails.put(ErrorCode.WORKER_EXIST_POLICY_REPATRIATION, null);
			}
		}

		for (MultipartFile document : documents) {

			String[] fileDetails = document.getOriginalFilename().split("\\.");
			String fileExt = fileDetails[fileDetails.length - 1];
			if (!Arrays.asList(claimFileTypes.replaceAll(", ", ",").split(",")).contains(fileExt)) {
				errorDetails.put(ErrorCode.INVALID_CLAIM_DOCUMENT,
						new Object[] { document.getOriginalFilename(), claimFileTypes });
			}
		}

		return errorDetails;
	}

	private Map<ErrorCode, Object[]> validateUpdateClaimRequest(UpdateClaimDTO updateClaimDTO,
			MultipartFile[] documents) {

		Map<ErrorCode, Object[]> errorDetails = new HashMap<>();

		if (StringUtils.isEmpty(updateClaimDTO.getComplaintNumber())
				|| StringUtils.isEmpty(updateClaimDTO.getWorkerEmiratesId())
				|| StringUtils.isEmpty(updateClaimDTO.getVisaReferenceNo())) {
			errorDetails.put(ErrorCode.EMPTY_MANDATORY_FIELD_CLAIM_UPDATE, null);
		}

		Claim claim = claimsRepository.findByComplaintNumberAndErrorType(updateClaimDTO.getComplaintNumber(), null);
		if (claim == null) {
			errorDetails.put(ErrorCode.CLAIM_DOES_NOT_EXIST, null);
		} else if (!claim.getEmiratesId().equals(updateClaimDTO.getWorkerEmiratesId())) {
			errorDetails.put(ErrorCode.COMPLAINT_NO_EMIRATES_ID_MISMATCH, null);
		}

		for (MultipartFile document : documents) {

			String[] fileDetails = document.getOriginalFilename().split("\\.");
			String fileExt = fileDetails[fileDetails.length - 1];
			if (!Arrays.asList(claimFileTypes.replaceAll(", ", ",").split(",")).contains(fileExt)) {
				errorDetails.put(ErrorCode.INVALID_CLAIM_DOCUMENT,
						new Object[] { document.getOriginalFilename(), claimFileTypes });
			}
		}

		return errorDetails;
	}

	public void addDocumentDetails(Claim claim, List<DMSDocumentMetadata> documentMetadataList) {

		if (claim.getSgsId() == 0) {
			claim = claimsRepository.findByComplaintNumberAndErrorType(claim.getComplaintNumber(), null);
			if (claim == null) {
				throw new ApplicationException(ErrorCode.CLAIM_DOES_NOT_EXIST);
			}
		}

		for (DMSDocumentMetadata document : documentMetadataList) {

			ClaimAdditionalDetails claimAdditionalDetails = new ClaimAdditionalDetails();
			claimAdditionalDetails.setClaim(claim);
			claimAdditionalDetails.setType("D");
			claimAdditionalDetails.setDocumentPath(document.getGridFSId());
			claimAdditionalDeatilsRepository.save(claimAdditionalDetails);
		}
	}

	private void addNotes(Claim claim, String notes) {

		if (!StringUtils.isEmpty(notes)) {

			ClaimAdditionalDetails claimAdditionalDetails = new ClaimAdditionalDetails();
			claimAdditionalDetails.setClaim(claim);
			claimAdditionalDetails.setType(ClaimRegistrationConstants.CLAIM_DOCUMNET_TYPE);
			claimAdditionalDetails.setNotes(notes);
			claimAdditionalDeatilsRepository.save(claimAdditionalDetails);
		}
	}

	// @Async
	@Transactional
	public void storeClaim(Claim claim) throws Exception {
		fnolData = saveClaimTransactionalFnol(claim);
		saveClaimaint(claim, fnolData);
		String partyId = savePartyDetails(fnolData);
		int riskfnolSgsID = saveRiskDetails(fnolData);
		saveClaimWorkingEstimation(claim, riskfnolSgsID, partyId);
		saveClaimTransactionEstimation();
		saveCalimHistortyEstimation();
		// saveDocumnetUploadDetails(claim, icadPath);
	}

	private ClaimTransactionFNOL saveClaimTransactionalFnol(Claim claim) throws ParseException {
		fnolData = new ClaimTransactionFNOL();
		policyData = new PolicyRisk();
		policyDatalist = policyRepository.getPolicyRiskDate(claim.getEmiratesId());
		if (policyDatalist != null && policyDatalist.size() > 0) {
			Object[] policyDataArray = policyDatalist.get(0);
			if (policyDataArray[0] != null) {
				policyData.setCompanyId(policyDataArray[0].toString());
			}
			if (policyDataArray[1] != null) {
				policyData.setPolicyNo(policyDataArray[1].toString());
			}
			if (policyDataArray[2] != null) {
				policyData.setPolicySgsId(policyDataArray[2].toString());
			}
			if (policyDataArray[3] != null) {
				policyData.setCustomerId(policyDataArray[3].toString());
			}
			if (policyDataArray[4] != null) {
				policyData.setProductId(policyDataArray[4].toString());
			}
			if (policyDataArray[5] != null) {
				policyData.setCobId(policyDataArray[5].toString());
			}
			if (policyDataArray[6] != null) {
				policyData.setPolicyEffectiveFrom(new Date(((Timestamp) policyDataArray[6]).getTime()));
			}
			if (policyDataArray[7] != null) {
				policyData.setPolicyEffectiveTo(new Date(((Timestamp) policyDataArray[7]).getTime()));
			}
			if (policyDataArray[8] != null) {
				policyData.setDivisionID(policyDataArray[8].toString());
			}
			if (policyDataArray[9] != null) {
				policyData.setDepartmentId(policyDataArray[9].toString());
			}
			if (policyDataArray[10] != null) {
				policyData.setInsuredId(policyDataArray[10].toString());
			}
			if (policyDataArray[11] != null) {
				policyData.setMasterPolicyNo(policyDataArray[11].toString());
			}
			if (policyDataArray[12] != null) {
				policyData.setMasterPolicyEffectiveFrom(new Date(((Timestamp) policyDataArray[12]).getTime()));
			}
			if (policyDataArray[13] != null) {
				policyData.setMasterPolicyEffectiveTo(new Date(((Timestamp) policyDataArray[13]).getTime()));
			}
			if (policyDataArray[14] != null) {
				policyData.setReportedDivisionID(policyDataArray[14].toString());
			}
			if (policyDataArray[15] != null) {
				policyData.setRiskId(policyDataArray[15].toString());
			}
			if (policyDataArray[16] != null) {
				policyData.setRiskEffectiveFrom(new Date(((Timestamp) policyDataArray[16]).getTime()));
			}
			if (policyDataArray[17] != null) {
				policyData.setRiskEffectiveTo(new Date(((Timestamp) policyDataArray[17]).getTime()));
			}
			if (policyDataArray[18] != null) {
				policyData.setRiskType(policyDataArray[18].toString());
			}
			if (policyDataArray[19] != null) {
				policyData.setFlex7(policyDataArray[19].toString());
			}
			if (policyDataArray[20] != null) {
				policyData.setRiskAmendmentVerNo(Integer.parseInt(policyDataArray[20].toString()));
			}
		}

		if (policyData != null) {
			fnolData = modelMapper.map(policyData, ClaimTransactionFNOL.class);
			fnolData.setCLF_REP_BY_ID(policyData.getInsuredId());
		}

		fnolData.setFnolRefNo(claim.getComplaintNumber());
		fnolData.setGroupId(claim.getGroupId());
		fnolData.setClaimReason(claim.getClaimReason());
		fnolData.setRemarks(claim.getRemarks());
		fnolData.setClaimReason2(claim.getClaimReason2());
		fnolData.setLossIntimationDate(claim.getClaimLaunchDate());
		fnolData.setLossDate(claim.getClaimLaunchDate());
		fnolData.setLossDescription(claim.getClaimDescription());
		fnolData.setLossDiscoveryDate(claim.getClaimLaunchDate());
		fnolData.setCLF_CLC_NO(claim.getComplaintNumber());

		companyId = claimsRepository.getCompanyId();
		fnolData.setCompanyId(companyId);

		fnolData.setCreatedDate(new Date());
		fnolData.setClaimantcustomerYN(ClaimRegistrationConstants.CLAIM_CLF_CLMNT_CUST_YN);
		fnolData.setReportedBy(claimsRepository.getReportedBy());
		fnolData.setFnolStatus(ClaimRegistrationConstants.CLAIM_FNOL_STATUS);
		fnolData.setCLF_REP_MTHD(ClaimRegistrationConstants.CLAIM_CLF_REP_MTHD);
		fnolData.setCLF_REP_BY(ClaimRegistrationConstants.CLAIM_CLF_REP_BY);
		createdUser = claimsRepository.getCreatedUser(companyId);
		if (createdUser != null) {
			fnolData.setCreatedUser(createdUser);
		}

		ClaimTransactionFNOL savedClaimFnol = claimFnolDetailsRepository.save(fnolData);
		cliamFnolSgsId = savedClaimFnol.getFnolSgsId();
		return savedClaimFnol;
	}

	private void saveClaimaint(Claim claim, ClaimTransactionFNOL claimtransactionalFnol) {
		ClaimTransactionClaim claimDetails = new ClaimTransactionClaim();
		if (policyData != null) {
			claimDetails = modelMapper.map(policyData, ClaimTransactionClaim.class);
			claimDetails.setCLC_REP_DIVN_ID(policyData.getReportedDivisionID());
		}
		claimDetails.setFnol(claimtransactionalFnol);
		claimDetails.setCompanyId(companyId);

		claimDetails.setClaimNo(claim.getComplaintNumber());
		claimDetails.setFnolNo(claim.getComplaintNumber());
		claimDetails.setClaimIntimationDate(claim.getClaimLaunchDate());
		claimDetails.setLossDate(claim.getClaimLaunchDate());
		claimDetails.setDiscoveryDate(claim.getClaimLaunchDate());
		claimDetails.setLossDescription(claim.getClaimDescription());
		claimDetails.setCreatedDate(new Date());
		claimDetails.setClaimReason(claim.getClaimReason());
		claimDetails.setClaimReason2(claim.getClaimReason2());
		claimDetails.setGroupId(claim.getGroupId());
		claimDetails.setRemarks(claim.getRemarks());

		claimDetails.setClaimStatus(ClaimRegistrationConstants.CLAIM_FNOL_STATUS);
		claimDetails.setCloseReasonId(null);
		if (createdUser != null) {
			claimDetails.setCreatedUser(createdUser);
		}

		claimDetails.setCreatedDate(new Date());

		claimDetailsRepository.save(claimDetails);
	}

	private String savePartyDetails(ClaimTransactionFNOL fnol) throws ParseException {
		ClaimTransactionClaimantDetails partyDetails = new ClaimTransactionClaimantDetails();
		List<Object[]> insuredDetailslist = insuredDetailsDataRepository.getInsuredData(policyData.getInsuredId());
		if (insuredDetailslist != null && insuredDetailslist.size() > 0) {
			Object[] insuredDeatilsArray = insuredDetailslist.get(0);
			if (insuredDeatilsArray != null) {
				if (insuredDeatilsArray[0] != null) {
					partyDetails.setFirstName(insuredDeatilsArray[0].toString());
				}
				if (insuredDeatilsArray[1] != null) {
					partyDetails.setLastName(insuredDeatilsArray[1].toString());
				}
				if (insuredDeatilsArray[2] != null) {
					partyDetails.setName(insuredDeatilsArray[2].toString());
				}
				if (insuredDeatilsArray[3] != null) {
					partyDetails.setAddress1(insuredDeatilsArray[3].toString());
				}
				if (insuredDeatilsArray[4] != null) {
					partyDetails.setAddress2(insuredDeatilsArray[4].toString());
				}
				if (insuredDeatilsArray[5] != null) {
					partyDetails.setAddress3(insuredDeatilsArray[5].toString());
				}
				if (insuredDeatilsArray[6] != null) {
					partyDetails.setAddress4(insuredDeatilsArray[6].toString());
				}
				if (insuredDeatilsArray[7] != null) {
					partyDetails.setPincode(insuredDeatilsArray[7].toString());
				}
				if (insuredDeatilsArray[8] != null) {
					partyDetails.setCity(insuredDeatilsArray[8].toString());
				}
				if (insuredDeatilsArray[9] != null) {
					partyDetails.setState(insuredDeatilsArray[9].toString());
				}
				if (insuredDeatilsArray[10] != null) {
					partyDetails.setCountryId(insuredDeatilsArray[10].toString());
				}
				if (insuredDeatilsArray[11] != null) {
					partyDetails.setPhoneNo(insuredDeatilsArray[11].toString());
				}
				if (insuredDeatilsArray[12] != null) {
					partyDetails.setMobileNo(insuredDeatilsArray[12].toString());
				}
				if (insuredDeatilsArray[13] != null) {
					partyDetails.setEmailId(insuredDeatilsArray[13].toString());
				}
				if (insuredDeatilsArray[14] != null) {
					partyDetails.setDob(new Date(((Timestamp) insuredDeatilsArray[14]).getTime()));
				}
				if (insuredDeatilsArray[15] != null) {
					partyDetails.setGender(insuredDeatilsArray[15].toString());
				}
				if (insuredDeatilsArray[16] != null) {
					partyDetails.setNationality(insuredDeatilsArray[16].toString());
				}
				if (insuredDeatilsArray[17] != null) {
					partyDetails.setPrefixName(insuredDeatilsArray[17].toString());
				}
			}
		}

		partyDetails.setMiddleName(null);
		partyDetails.setPartyId(policyData.getInsuredId());
		partyDetails.setFnol(fnol);
		partyDetails.setPartyType(ClaimRegistrationConstants.CLAIM_PARTY_TYPE);
		partyDetails.setLanguage(ClaimRegistrationConstants.CLAIM_DEFAULT_LANGUAGE);
		partyDetails.setRecordType(ClaimRegistrationConstants.CLAIM_RECORD_TYP);
		partyDetails.setReportedByClaimantYN(ClaimRegistrationConstants.CLAIM_CLF_REP_BY_CLMNT_YN);
		partyDetails.setOtherLanguage(ClaimRegistrationConstants.CLAIM_OTHER_LANGUAGE);
		partyDetails.setCreatedDate(new Date());
		if (createdUser != null) {
			partyDetails.setCreatedUser(createdUser);
		}
		insuredDetailsDataRepository.save(partyDetails);
		return partyDetails.getPartyId();
	}

	private int saveRiskDetails(ClaimTransactionFNOL claimFnol) {
		ClaimTransactionRisk claimRisk = new ClaimTransactionRisk();
		claimRisk.setFnolSgsId(cliamFnolSgsId);
		if (policyData != null) {
			claimRisk.setRiskId(policyData.getRiskId());
			claimRisk.setRiskType(policyData.getRiskType());
			claimRisk.setPolicyNo(policyData.getPolicyNo());
			claimRisk.setRiskCOB(policyData.getCobId());
			claimRisk.setRiskEffectiveFrom(policyData.getRiskEffectiveFrom());
			claimRisk.setRiskEffectiveTo(policyData.getRiskEffectiveTo());
			claimRisk.setCLR_RISK_AMND_IDX(policyData.getRiskAmendmentVerNo());
			claimRisk.setEmiratesId(policyData.getFlex7());
		}
		claimRisk.setCompanyId(companyId);

		claimTransactionRiskRepository.save(claimRisk);
		return claimRisk.getFnolSgsId();

	}

	private void saveClaimWorkingEstimation(Claim claim, int riskfnolSgsID, String partyId) {
		workingEstm = new ClaimWorkingEstimation();
		workingEstm.setFnolSgsId(cliamFnolSgsId);
		workingEstm.setRevisionSerialNo(ClaimRegistrationConstants.CLAIM_DEFAULT_REVISION_SERIAL_NO);
		if (policyData.getRiskId() != null) {
			workingEstm.setRiskId(policyData.getRiskId());
		}
		List<Object[]> cudsResultList = claimWorkingDetailsRepository.getCUDS_EST_DEFNData(fnolData.getFnolSgsId(),
				riskfnolSgsID, claim.getPayeeType(), claim.getClaimPaymentType());

		if (cudsResultList != null && cudsResultList.size() > 0) {
			Object[] cudsResult = cudsResultList.get(0);
			workingEstm.setCoverId(cudsResult[1].toString());
			workingEstm.setSmiId(cudsResult[2].toString());
			workingEstm.setLossId(cudsResult[3].toString());
			workingEstm.setEstimateType(cudsResult[0].toString());
			workingEstm.setEstimatedAmount(Integer.parseInt(cudsResult[4].toString()));
		}
		workingEstm.setEstimatedDate(new Date());
		workingEstm.setEstimateLevel(ClaimRegistrationConstants.CLAIM_CLE_EST_LVL);
		workingEstm.setApproveFlag(ClaimRegistrationConstants.CLAIM_APPROVE_FLAG);
		workingEstm.setCloseFlag(null);
		workingEstm.setCloseDate(null);
		if (createdUser != null) {
			workingEstm.setCreatedUser(createdUser);
		}
		workingEstm.setOutstandingAmount(claim.getPaymentAmount());
		workingEstm.setSettlementRefsgsId(0); // CTDS_LEVEL_S=>CLS_SGS_ID
		workingEstm.setEstimateDescription(null);
		workingEstm.setEstimateType(claim.getPayeeType());
		workingEstm.setExchangeRate(ClaimRegistrationConstants.CLAIM_EXCHANGE_RATE);
		workingEstm.setCurrencyId(ClaimRegistrationConstants.CLAIM_CURRENCY_ID);
		workingEstm.setCloseReasonID(null);
		workingEstm.setLosstype(claim.getClaimPaymentType());
		workingEstm.setCLE_EXP_PARTY_ID(partyId);
		workingEstm.setApproveStatus(ClaimRegistrationConstants.CLAIM_APPROVE_STATUS);
		workingEstm.setCLE_APU(ClaimRegistrationConstants.CLAIM_CLE_APU);
		workingEstm.setType(ClaimRegistrationConstants.CLAIM_CLE_TYP);
		if (createdUser != null) {
			workingEstm.setCLE_ASSIGN_APU(createdUser);
		}
		workingEstm.setUpdatedUser(null);
		workingEstm.setUpdatedDate(new Date());
		workingEstm.setCompanyId(companyId);
		if (policyData.getInsuredId() != null) {
			workingEstm.setCustomerId(policyData.getInsuredId());
		}

		claimWorkingDetailsRepository.save(workingEstm);
	}

	private void saveClaimTransactionEstimation() {
		// 6. storing data in CTDS_LEVEL_E
		ClaimTransactionEstimation claimTransactionEstimation = modelMapper.map(workingEstm,
				ClaimTransactionEstimation.class);
		claimTransactionEstimationRepository.save(claimTransactionEstimation);
	}

	private void saveCalimHistortyEstimation() {
		// 7. storing data in CHDS_LEVEL_E
		ClaimHistoryEstimation claimHistoryEstimation = modelMapper.map(workingEstm, ClaimHistoryEstimation.class);
		claimHistoryEstimation.setOldEstimatedAmount(ClaimRegistrationConstants.CLAIM_OLD_ESTMT_AMT);
		claimEstimationHistoryRepository.save(claimHistoryEstimation);
	}

	private void saveDocumnetUploadDetails(Claim claim, String icadPath) {
		UploadDocumentEntity uploadDoc = new UploadDocumentEntity();
		uploadDoc.setFnolSgsId(cliamFnolSgsId);
		uploadDoc.setTLD_TXN_SREF_NO(ClaimRegistrationConstants.CLAIM_TLD_TXN_SREF_NO);
		uploadDoc.setIsMandatory(ClaimRegistrationConstants.CLAIM_DOCUMENT_IS_MANDATORY);
		uploadDoc.setUploadedDate(new Date());
		uploadDoc.setComplaintNo(claim.getComplaintNumber());
		uploadDoc.setCreatedDate(new Date());
		uploadDoc.setFolderName(icadPath);
		uploadDoc.setTLD_VER_NO(ClaimRegistrationConstants.CLAIM_TLD_VER_NO);
		uploadDoc.setTLD_APPRV_STATUS(ClaimRegistrationConstants.CLAIM_TLD_APPRV_STATUS);
		uploadDoc.setApprovedDate(new Date());
		uploadDoc.setRecordType(ClaimRegistrationConstants.CLAIM_RECORD_TYP);

		uploadDoc.setSerialNo(0); // should be incremental
		uploadDoc.setDocumentStatus(ClaimRegistrationConstants.CLAIM_DOCUMENT_STATUS);
		uploadDoc.setModuleType(ClaimRegistrationConstants.CLAIM_MODULE_TYP);
		uploadDoc.setUploadedUser("");// have to confirm
		uploadDoc.setDocumentId("");
		uploadDoc.setDocumentType(""); // name of the document
		// TLD_CRU, TLD_APU, TLD_DOC_ID, TLD_DOC_DESC, TLD_DOC_NAME, TLD_TYP
		uploadDocumentRepository.save(uploadDoc);
	}

	@Transactional
	public ClaimFieldListingDTO getSearchCriteriaValues(String companyId) {

		List<Object[]> departmentDetails = claimsRepository.getDepartmentDetails(companyId);
		List<Object[]> divisionDetails = claimsRepository.getDivisionDetails(companyId);
		List<Object[]> statusTypes = claimsRepository.getStatusDetails();
		List<Object[]> workerTypes = claimsRepository.getWorkerTypes();
		List<Object[]> sponsorTypes = claimsRepository.getSponsorTypes();
		ClaimFieldListingDTO claimFieldsData = new ClaimFieldListingDTO();

		if (departmentDetails != null && departmentDetails.size() != 0) {
			Map<String, String> department = new HashMap<String, String>();

			for (Object[] details : departmentDetails) {
				department.put((String) details[0], (String) details[1]);
			}
			claimFieldsData.setDepartment(department);
		}

		if (divisionDetails != null && divisionDetails.size() != 0) {
			Map<String, String> division = new HashMap<String, String>();

			for (Object[] details : divisionDetails) {
				division.put((String) details[0], (String) details[1]);
			}
			claimFieldsData.setDivision(division);
		}

		if (statusTypes != null && statusTypes.size() != 0) {
			Map<String, String> status = new HashMap<String, String>();

			for (Object[] details : statusTypes) {
				status.put((String) details[0], (String) details[1]);
			}
			claimFieldsData.setStatusTypes(status);
		}

		if (workerTypes != null && workerTypes.size() != 0) {
			Map<String, String> employee = new HashMap<String, String>();

			for (Object[] details : workerTypes) {
				employee.put((String) details[0], (String) details[1]);
			}
			claimFieldsData.setWorkerTypes(employee);
		}

		if (sponsorTypes != null && sponsorTypes.size() != 0) {
			Map<String, String> sponsor = new HashMap<String, String>();

			for (Object[] details : sponsorTypes) {
				sponsor.put((String) details[0], (String) details[1]);
			}
			claimFieldsData.setSponsorTypes(sponsor);
		}

		return claimFieldsData;
	}

	private String getErrorMessage(ErrorCode errorCode, Object[] args, Locale locale) {
		return messageSource.getMessage(errorCode.getCode(), args, locale);
	}

	private String getErrorMessage(ErrorCode errorCode, Locale locale) {
		return getErrorMessage(errorCode, null, locale);
	}

	public PaymentListingDTO getPayemntListingDTO(String claimNo) {

		String sponsorName = null;
		PaymentListingDTO paymentListingDTO = new PaymentListingDTO();
		ClaimTransactionClaim ctdsLevelC = claimDetailsRepository.findByClaimNo(claimNo);
		Claim claim = claimsRepository.findByComplaintNumber(claimNo);

		String employeeName = insuredDetailsDataRepository.getInsuredName(ctdsLevelC.getFnolSgsId());
		String insuredId = claimFnolDetailsRepository.getInsuredId(ctdsLevelC.getFnolSgsId());
		sponsorName = claimFnolDetailsRepository.getSponsorName(Integer.parseInt(insuredId));

		ClaimDetails claimDetails = new ClaimDetails();

		if (!StringUtils.isEmpty(ctdsLevelC.getPolicyNo())) {
			claimDetails.setCertificateNo(ctdsLevelC.getPolicyNo());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getClaimNo())) {
			claimDetails.setClaimNo(ctdsLevelC.getClaimNo());
		}
		if (!StringUtils.isEmpty(claim.getClaimStatus())) {
			claimDetails.setClaimStatus(ctdsLevelC.getClaimStatus());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getLossDate())) {
			claimDetails.setLossDate(ctdsLevelC.getLossDate());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getCreatedDate())) {
			claimDetails.setCreatedDate(ctdsLevelC.getCreatedDate());
		}
		if (!StringUtils.isEmpty(ctdsLevelC.getProductId())) {
			claimDetails.setProductName(ctdsLevelC.getProductId());
		}
		if (!StringUtils.isEmpty(employeeName)) {
			claimDetails.setInsuredName(employeeName);
		}

		if (!StringUtils.isEmpty(sponsorName)) {
			claimDetails.setSponsorName(sponsorName);

		}
		paymentListingDTO.setClaimDetails(claimDetails);

		List<ClaimTransactionEstimation> paymentEstimationList = claimTransactionEstimationRepository
				.findByFnolSgsId(ctdsLevelC.getFnolSgsId());
		List<PaymentEstimateDetails> paymentEstimateDetails = new ArrayList<>();
		for (ClaimTransactionEstimation paymentestmt : paymentEstimationList) {
			PaymentEstimateDetails paymentDetails = new PaymentEstimateDetails();
			paymentDetails.setCover(paymentestmt.getCoverId());
			paymentDetails.setLossType(paymentestmt.getLosstype());
			paymentDetails.setDate(paymentestmt.getEstimatedDate());
			paymentDetails.setAmount("AED " + paymentestmt.getEstimatedAmount());
			String settledAmount = claimsRepository.getSettledAmount(paymentestmt.getFnolSgsId());
			if (!StringUtils.isEmpty(settledAmount)) {
				paymentDetails.setSettled("AED " + Float.parseFloat(settledAmount));
			} else {
				paymentDetails.setSettled("AED " + 0);
			}

			paymentDetails.setOutstandingAmount("AED " + paymentestmt.getOutstandingAmount());

			paymentEstimateDetails.add(paymentDetails);
		}

		paymentListingDTO.setPaymentEstimateDetails(paymentEstimateDetails);

		/*
		 * PaymentReview paymentReview = new PaymentReview(); List<Object[]>
		 * paymentdtlsList = claimTransactionPayment.getPaymentDetails(cliamFnolSgsId);
		 * if(paymentdtlsList != null && paymentdtlsList.size()>0) { Object[]
		 * payemntDtls = paymentdtlsList.get(0);
		 * paymentReview.setRequestedPersonName("mol"); paymentReview.setCover(cover); }
		 */
		return paymentListingDTO;
	}

	public List<String> getActions(String claimNo, Locale locale) {
		String claimStatus = claimDetailsRepository.getClaimStatus(claimNo);
		List<String> claimActions = new ArrayList<>();
		if (claimStatus.equals("CS")) {
			claimActions.add(getErrorMessage(ErrorCode.DECLINE_CLAIM, locale));
			claimActions.add(getErrorMessage(ErrorCode.CLOSE_CLAIM, locale));
		}
		if (claimStatus.equals("CL")) {

		}
		if (claimStatus.equals("RO")) {
			claimActions.add(getErrorMessage(ErrorCode.DECLINE_CLAIM, locale));
			claimActions.add(getErrorMessage(ErrorCode.CLOSE_CLAIM, locale));
		}
		if (claimStatus.equals("CD")) {
			claimActions.add(getErrorMessage(ErrorCode.RE_OPEN_CLAIM, locale));
		}
		return claimActions;
	}
}
