package com.beyontec.mol.service;

import java.io.File;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.modal.DMSDocumentMetadata;
import com.beyontec.mol.modal.DMSDocumentMetadataDTO;
import com.beyontec.mol.util.DMSConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DMSService {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private RestTemplate restTemplate;

	@Value("${dms.uri}")
	private String dmsBaseUrl;

	public List<DMSDocumentMetadata> getDocumentList(DMSDocumentMetadataDTO documentMetadataDTO, String authHeader)
			throws Exception {

		String url = MessageFormat.format(dmsBaseUrl + DMSConstants.GET_DOCUMENT_LIST,
				documentMetadataDTO.getEntityRefId(), documentMetadataDTO.getEntityRefType());

		ResponseEntity<String> response = null;
		try {
			response = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<Object>(getHttpHeaders(authHeader)),
					String.class);
		} catch (Exception ex) {
			handleException(ex);
		}

		return Arrays.asList(objectMapper.readValue(response.getBody().toString(), DMSDocumentMetadata[].class));
	}

	public byte[] getDocument(String gridFSId, String authHeader) throws Exception {

		String url = MessageFormat.format(dmsBaseUrl + DMSConstants.GET_DOCUMENT_CONTENT, gridFSId);

		ResponseEntity<byte[]> response = null;
		try {
			response = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<Object>(getHttpHeaders(authHeader)),
					byte[].class);
		} catch (Exception ex) {
			handleException(ex);
		}

		return response.getBody();
	}

	public boolean deleteDocument(String gridFSId, String authHeader) throws Exception {

		String url = MessageFormat.format(dmsBaseUrl + DMSConstants.DELETE_DOCUMENT_CONTENT, gridFSId);

		try {
			restTemplate.exchange(url, HttpMethod.DELETE, new HttpEntity<Object>(getHttpHeaders(authHeader)),
					String.class);
		} catch (Exception ex) {
			handleException(ex);
		}

		return true;
	}

	public List<DMSDocumentMetadata> uploadDocument(DMSDocumentMetadataDTO documentMetadataDTO,
			MultipartFile[] documents, String authHeader) throws Exception {

		FileSystemResource[] fileSystemResources = new FileSystemResource[documents.length];

		int index = 0;
		for (MultipartFile document : documents) {

			int extIndex = document.getOriginalFilename().lastIndexOf(".");
			File file = File.createTempFile(document.getOriginalFilename().substring(0, extIndex),
					document.getOriginalFilename().substring(extIndex));
			document.transferTo(file);
			fileSystemResources[index] = new FileSystemResource(file);
			index++;
		}

		return uploadDocument(documentMetadataDTO, fileSystemResources, authHeader);
	}

	public DMSDocumentMetadata uploadDocument(DMSDocumentMetadataDTO documentMetadataDTO, FileSystemResource document,
			String authHeader) throws Exception {

		List<DMSDocumentMetadata> dmsDocumentMetadatas = uploadDocument(documentMetadataDTO,
				new FileSystemResource[] { document }, authHeader);
		return (dmsDocumentMetadatas != null && dmsDocumentMetadatas.size() > 0) ? dmsDocumentMetadatas.get(0) : null;
	}

	private List<DMSDocumentMetadata> uploadDocument(DMSDocumentMetadataDTO documentMetadataDTO,
			FileSystemResource[] documents, String authHeader) throws Exception {

		HttpHeaders headers = getHttpHeaders(authHeader);
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);

		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add(DMSConstants.METADATA, objectMapper.writeValueAsString(documentMetadataDTO));
		for (FileSystemResource document : documents) {
			body.add(DMSConstants.DOCUMENTS, document);
		}

		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
		ResponseEntity<String> response = null;
		try {
			response = restTemplate.postForEntity(dmsBaseUrl + DMSConstants.UPLOAD_DOCUMENTS_URI, requestEntity,
					String.class);
		} catch (Exception ex) {
			handleException(ex);
		}

		return Arrays.asList(objectMapper.readValue(response.getBody().toString(), DMSDocumentMetadata[].class));
	}

	private HttpHeaders getHttpHeaders(String authHeader) {

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.AUTHORIZATION, authHeader);

		return headers;
	}

	private void handleException(Exception ex) throws Exception {

		if (ex instanceof HttpClientErrorException) {
			throw new ApplicationException(ErrorCode.get(objectMapper
					.readTree(((HttpClientErrorException) ex).getResponseBodyAsString()).get("code").toString()));
		} else {
			throw new ApplicationException(ErrorCode.SERVER_ERROR_DMS);
		}
	}
}