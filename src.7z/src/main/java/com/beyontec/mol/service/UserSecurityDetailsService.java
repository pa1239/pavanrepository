package com.beyontec.mol.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import com.beyontec.mol.entity.User;
import com.beyontec.mol.entity.UserGroup;
import com.beyontec.mol.entity.UserGroupPermission;
import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.repository.UserRepository;
import com.beyontec.mol.util.ValidationUtil;

@Component
public class UserSecurityDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ValidationUtil validationUtil;

    @Override
    public UserDetails loadUserByUsername(String username) throws ApplicationException {

        User user = userRepository.findByLoginId(username);

        // Validating user details
        validationUtil.validateUserDetails(user);

        Set<GrantedAuthority> authorities = generateAuthorities(user);
        UserDetails userDetails = new org.springframework.security.core.userdetails.User(user.getLoginId(), 
                user.getPassword(), authorities);
        return userDetails;
    }

    private Set<GrantedAuthority> generateAuthorities(User user) {

        Set<String> userPermissionList = new HashSet<String>();
        for (UserGroup userGroup : user.getUserGroups()) {
            for (UserGroupPermission userPermission: userGroup.getUserGroupPermissions()) {

                String permission = userPermission.getName();

                if ("Y".equalsIgnoreCase(userPermission.getCreatePermission())) {
                    userPermissionList.add(permission + "_create");
                }

                if ("Y".equalsIgnoreCase(userPermission.getDeletePermission())) {
                    userPermissionList.add(permission + "_delete");
                }

                if ("Y".equalsIgnoreCase(userPermission.getEditPermission())) {
                    userPermissionList.add(permission + "_update");
                }

                if ("Y".equalsIgnoreCase(userPermission.getViewPermission())) {
                    userPermissionList.add(permission + "_read");
                }
            }
        }

        Set<GrantedAuthority> authorities = new HashSet<>();
        for (String permission : userPermissionList) {
            authorities.add(new SimpleGrantedAuthority(permission));
        }

        return authorities;
    }
}
