package com.beyontec.mol.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.beyontec.mol.config.CommonConfig;
import com.beyontec.mol.entity.CertificateDetails;
import com.beyontec.mol.entity.CustomerDetailsHistory;
import com.beyontec.mol.entity.CustomerDetailsMain;
import com.beyontec.mol.entity.PolicyHistory;
import com.beyontec.mol.entity.PolicyMain;
import com.beyontec.mol.entity.ProductAppBusType;
import com.beyontec.mol.entity.RiskAdditionalHistory;
import com.beyontec.mol.entity.RiskAdditionalMain;
import com.beyontec.mol.entity.RiskHistory;
import com.beyontec.mol.entity.RiskMain;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.exception.ValidationException;
import com.beyontec.mol.modal.CancelCertificateDTO;
import com.beyontec.mol.modal.CertificateDTO;
import com.beyontec.mol.modal.DMSDocumentMetadata;
import com.beyontec.mol.modal.DMSDocumentMetadataDTO;
import com.beyontec.mol.repository.CertificateDetailsRepository;
import com.beyontec.mol.repository.CustomerDetailsHistoryRepository;
import com.beyontec.mol.repository.CustomerDetailsMainRepository;
import com.beyontec.mol.repository.PolicyHistoryRepository;
import com.beyontec.mol.repository.PolicyMainRepository;
import com.beyontec.mol.repository.ProductAppBusTypeRepository;
import com.beyontec.mol.repository.RiskAdditionalHistoryRepository;
import com.beyontec.mol.repository.RiskAdditionalMainRepository;
import com.beyontec.mol.repository.RiskHistoryRepository;
import com.beyontec.mol.repository.RiskMainRepository;
import com.beyontec.mol.util.AppConstants;
import com.beyontec.mol.util.CustomDateSerializer;
import com.beyontec.mol.util.DMSConstants;
import com.beyontec.mol.util.DateUtil;
import com.beyontec.mol.util.PdfGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

@Service
public class CertificateService extends BaseService {

	@Autowired
	private CertificateDetailsRepository certificateDetailsRepository;

	@Autowired
    private PolicyHistoryRepository policyHistoryRepository;

    @Autowired private CustomerDetailsMainRepository customerDetailsMainRepo;

    @Autowired private CustomerDetailsHistoryRepository customerDetailsHistoryRepo;

    @Autowired private ProductAppBusTypeRepository productAppBusTypeRepo;

    @Autowired private PolicyMainRepository policyMainRepo;

    @Autowired private RiskMainRepository riskMainRepo;

    @Autowired private RiskHistoryRepository riskHistoryRepo;

    @Autowired private RiskAdditionalMainRepository riskAdditionalMainRepo;

    @Autowired private RiskAdditionalHistoryRepository riskAdditionalHistoryRepo;

    @Autowired
	private DMSService dmsService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private PdfGenerator pdfGenerator;

	@Value("${date.format}")
	private String dateFormat;

	@Transactional
    public Map<String, Object> createCertificate(CertificateDTO certificateDTO,
                                                 PolicyHistory masterPolicy,
                                                 boolean isValidationFailed,
                                                 String authHeader) throws Exception {

		Map<String, Object> result = new HashMap<>();
        CertificateDetails certificateDetails = invokeModelMapper(() -> modelMapper.map(certificateDTO,
                                                                                        CertificateDetails.class),
                                                                  "modelMapper.map(certificateDTO, CertificateDetails.class)");
		String certificateNo = null;
		Map<ErrorCode, Object[]> errorDetails = validateCertificateRequest(certificateDTO, isValidationFailed);

		if (errorDetails.size() > 0) {
			result.put(AppConstants.ERRORS, errorDetails);
			return result;
		}

        certificateNo = getPolicyNo(certificateDTO, masterPolicy);
        certificateDetails.setCertificateNumber(certificateNo);
		result.put(AppConstants.CERTIFICATE_NO, certificateNo);

		// Generate certificate and upload it to DMS
		FileSystemResource certificate = generateCertificate(certificateDetails, certificateNo);
		DMSDocumentMetadataDTO documentMetadataDTO = new DMSDocumentMetadataDTO(certificateNo,
				DMSConstants.REF_TYPE_CERTIFICATE);
		DMSDocumentMetadata documentMetadata = dmsService.uploadDocument(documentMetadataDTO, certificate, authHeader);

		// Update certificate details
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.ENGLISH);
		Date documentGenDate = format.parse(documentMetadata.getUploadedDateTime());
		certificateDetails.setDocumentGenDate(documentGenDate);
		certificateDetails.setDocumentPath(documentMetadata.getGridFSId());
        certificateDetails.setReqInDate(DateUtil.getCurrentDate());
        invokeRepo(() -> certificateDetailsRepository.save(certificateDetails),
                   "certificateDetailsRepository.save(certificateDetails)");
		return result;
	}

	@Async
	@Transactional
    public void addCertificateEntries(CertificateDTO certificateDTO,
                                      String certificateNo,
                                      PolicyHistory masterPolicy) throws Exception {
        CertificateDetails certificateDetails = invokeRepo(() -> certificateDetailsRepository.findByCertificateNumber(certificateNo),
                                                           "certificateDetailsRepository.findByCertificatePolicyNumber(certificateNo)");

        PolicyMain certificatePolicyMain = createCertificatePolicyMain(certificateDTO,
                                                                       certificateDetails,
                                                                       masterPolicy);
        createCertificatePolicyHistory(certificatePolicyMain);

        RiskMain riskMain = createRiskMain(certificateDetails, masterPolicy, certificatePolicyMain);
        createRiskHistory(riskMain);

        RiskAdditionalMain riskAdditionalMain = createRiskAdditionalMain(riskMain,
                                                                         certificateDetails,
                                                                         certificatePolicyMain);
        createRiskAdditionalHistory(riskAdditionalMain);
	}

    private PolicyMain createCertificatePolicyMain(CertificateDTO certificateDTO,
                                                   CertificateDetails certificateDetails,
                                                   PolicyHistory masterPolicy) {
        PolicyMain certificatePolicyMain = new PolicyMain();
        certificatePolicyMain.loadDefaults();
        certificatePolicyMain.loadFromUdsIdDefinition();
        certificatePolicyMain.loadFromMasterPolicy(masterPolicy);

        // Load from Certificate Details
        certificatePolicyMain.loadFromCertificateDetails(certificateDetails);

        // Load from Customer Details
        CustomerDetailsMain customerDetailsMain = getCustomerDetails(certificateDetails, masterPolicy);
        certificatePolicyMain.loadFromCustomerDetails(customerDetailsMain);

        // Load from Product App Bus Type
        ProductAppBusType productAppBusType = invokeRepo(() -> productAppBusTypeRepo.findByCompanyAndProduct(CommonConfig.COMPANY_ID,
                                                                                                             masterPolicy.getProductId()),
                                                         "productAppBusTypeRepo.findByCompanyAndProduct(CommonConfig.COMPANY_ID, masterPolicy.getProductId())");
        certificatePolicyMain.loadFromProductAppBusType(productAppBusType);

        PolicyMain createdCertificatePolicyMain = invokeRepo(() -> policyMainRepo.save(certificatePolicyMain),
                                                             "policyMainRepo.save(certificatePolicyMain)");
        return createdCertificatePolicyMain;
	}

    private CustomerDetailsMain getCustomerDetails(CertificateDetails certificateDetails, PolicyHistory masterPolicy) {
        String defaultCustomerIdType1 = CommonConfig.getUdsIdDefinitionValue(CommonConfig.UDS_ID_DEF_TYPE_DEFAULT_DATA,
                                                                             CommonConfig.UDS_ID_DEF_ID_DEFAULT_CUST_ID_TYPE1);
        CustomerDetailsMain customerDetailsMain = invokeRepo(() -> customerDetailsMainRepo.findByIdTypeAndId(CommonConfig.COMPANY_ID,
                                                                                                             defaultCustomerIdType1,
                                                                                                             certificateDetails.getEmployerLicenseNo()),
                                                             "customerDetailsRepo.findByIdTypeAndId(CommonConfig.COMPANY_ID, customerDetailsDefinition.getUID_VALUE(), certificateDetails.getEmployerLicenseNo()");
        if (customerDetailsMain == null) {
            customerDetailsMain = createCustomerDetails(certificateDetails, masterPolicy);
            createCustomerDetailsHistory(customerDetailsMain);
        }
        return customerDetailsMain;
    }

    private void createCertificatePolicyHistory(PolicyMain certificatePolicyMain) {
        PolicyHistory certificatePolicyHistory = invokeModelMapper(() -> modelMapper.map(certificatePolicyMain,
                                                                                         PolicyHistory.class),
                                                                   "modelMapper.map(certificatePolicyMain, PolicyHistory.class)");
        certificatePolicyHistory.loadDefaults();
        invokeRepo(() -> policyHistoryRepository.save(certificatePolicyHistory),
                   "policyHistoryRepository.save(certificatePolicyHistory)");
    }

    private CustomerDetailsMain createCustomerDetails(CertificateDetails certificateDetails,
                                                      PolicyHistory masterPolicy) {
        CustomerDetailsMain customerDetailsMain = new CustomerDetailsMain();
        customerDetailsMain.loadDefaults();
        customerDetailsMain.loadFromCertificateDetails(certificateDetails);
        customerDetailsMain.loadFromUdsIdDefinition(certificateDetails);
        customerDetailsMain.loadFromMasterPolicy(masterPolicy);
        CustomerDetailsMain createdCustomerDetailsMain = invokeRepo(() -> customerDetailsMainRepo.save(customerDetailsMain),
                                                                    "customerDetailsMainRepo.save(customerDetailsMain)");
        return createdCustomerDetailsMain;
    }

    private void createCustomerDetailsHistory(CustomerDetailsMain customerDetailsMain) {
        CustomerDetailsHistory customerDetailsHistory = invokeModelMapper(() -> modelMapper.map(customerDetailsMain,
                                                                                                CustomerDetailsHistory.class),
                                                                          "modelMapper.map(customerDetails, CustomerDetailsHistory.class)");
        invokeRepo(() -> customerDetailsHistoryRepo.save(customerDetailsHistory),
                   "customerDetailsHistoryRepo.save(customerDetailsHistory)");
    }

    private RiskMain createRiskMain(CertificateDetails certificateDetails,
                                    PolicyHistory masterPolicy,
                                    PolicyMain policyMain) {
        RiskMain riskMain = new RiskMain();
        riskMain.loadDefaults();
        riskMain.loadFromCertificateDetails(certificateDetails);
        riskMain.loadFromPolicyMain(policyMain);

        String riskType = CommonConfig.getRiskType(certificateDetails.getEmployeeCategory());
        RiskHistory masterRisk = riskHistoryRepo.findMasterRisk(masterPolicy.getSgsId(),
                                                                masterPolicy.getAmendmentVersionNumber(),
                                                                riskType);
        riskMain.loadFromMasterRisk(masterRisk);

        RiskMain createdRiskMain = invokeRepo(() -> riskMainRepo.save(riskMain), "riskMainRepo.save(riskMain)");
        return createdRiskMain;
    }

    private void createRiskHistory(RiskMain riskMain) {
        RiskHistory riskHistory = invokeModelMapper(() -> modelMapper.map(riskMain, RiskHistory.class),
                                                    "modelMapper.map(riskMain, RiskHistory.class)");
        riskHistory.loadDefaults();
        invokeRepo(() -> riskHistoryRepo.save(riskHistory), "riskHistoryRepo.save(riskHistory)");
    }

    private RiskAdditionalMain createRiskAdditionalMain(RiskMain riskMain,
                                                        CertificateDetails certificateDetails,
                                                        PolicyMain certificatePolicy) {
        RiskAdditionalMain riskAdditionalMain = new RiskAdditionalMain();
        riskAdditionalMain.loadDefaults();
        riskAdditionalMain.loadFromRiskMain(riskMain);
        riskAdditionalMain.loadFromCertificatePolicy(certificatePolicy);
        riskAdditionalMain.loadFromCertificateDetails(certificateDetails);

        RiskAdditionalMain createdRiskAdditionalMain = invokeRepo(() -> riskAdditionalMainRepo.save(riskAdditionalMain),
                                                                  "riskAdditionalMainRepo.save(riskAdditionalMain)");
        return createdRiskAdditionalMain;
    }

    private void createRiskAdditionalHistory(RiskAdditionalMain riskAdditionalMain) {
        RiskAdditionalHistory riskAdditionalHistory = invokeModelMapper(() -> modelMapper.map(riskAdditionalMain,
                                                                                              RiskAdditionalHistory.class),
                                                                        "modelMapper.map(riskAdditionalMain, RiskAdditionalHistory.class)");
        riskAdditionalHistory.loadDefaults();
        invokeRepo(() -> riskAdditionalHistoryRepo.save(riskAdditionalHistory),
                   "riskAdditionalHistoryRepo.save(riskAdditionalHistory)");
    }

	@Transactional
	public boolean cancelCertificate(CancelCertificateDTO cancelCertificateDTO, boolean isValidationFailed)
			throws Exception {

		Map<ErrorCode, Object[]> errorDetails = new HashMap<>();

        PolicyMain certificatePolicyMain = invokeRepo(() -> policyMainRepo.findByNumber(cancelCertificateDTO.getCertificateNo()),
                                                      "policyMainRepo.findByNumber(cancelCertificateDTO.getCertificateNo())");

		if (isValidationFailed) {
			errorDetails.put(ErrorCode.EMPTY_MANDATORY_FIELD_CANCEL_CERTIFICATE, null);
		}

		if (certificatePolicyMain == null) {
			errorDetails.put(ErrorCode.CERTIFICATE_NOT_AVAILABLE, null);
		} else {

			if (cancelCertificateDTO.getCancelledDate().compareTo(certificatePolicyMain.getFromDate()) < 0) {
				errorDetails.put(ErrorCode.CANCEL_LESS_VISA_APPROVAL, null);
			}

			if (cancelCertificateDTO.getCancelledDate().compareTo(certificatePolicyMain.getToDate()) > 0) {
				errorDetails.put(ErrorCode.CANCEL_OUT_OF_CERTIFICATE, null);
			}

			if (certificatePolicyMain.getStatus().equals("CAN")) {
				errorDetails.put(ErrorCode.ALREADY_CANCELLED_CERTIFICATE, null);
			}

            if (!certificatePolicyMain.getGlobalEndNumber().equals(cancelCertificateDTO.getLabourReferenceNo())) {
				errorDetails.put(ErrorCode.CERTIFICATE_LABOUR_REFERENCE_MISMATCH, null);
			}
		}

		if (errorDetails.size() > 0) {
			throw new ValidationException(errorDetails);
		}

		return true;
	}

	@Async
	@Transactional
	public void cancelCertificateEntries(CancelCertificateDTO cancelCertificateDTO) {
        PolicyMain certificatePolicyMain = invokeRepo(() -> policyMainRepo.findByNumber(cancelCertificateDTO.getCertificateNo()),
                                                      "policyMainRepo.findByNumber(cancelCertificateDTO.getCertificateNo())");
		certificatePolicyMain.setStatus("CAN");
        invokeRepo(() -> policyMainRepo.save(certificatePolicyMain), "policyMainRepo.save(certificatePolicyMain)");
	}


    private String getPolicyNo(CertificateDTO certificateDTO, PolicyHistory masterPolicy) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyhhmmssSSS");
		return dateFormat.format(new Date());
	}

	private Map<ErrorCode, Object[]> validateCertificateRequest(CertificateDTO certificateDTO,
			boolean isValidationFailed) {

		Map<ErrorCode, Object[]> errorDetails = new HashMap<>();

		if (isValidationFailed || (StringUtils.isEmpty(certificateDTO.getMohreJobId())
				&& StringUtils.isEmpty(certificateDTO.getEnscoJobId()))) {
			errorDetails.put(ErrorCode.EMPTY_MANDATORY_FIELD, null);
		}

		if (certificateDTO.getDateOfBirth() == null) {
			errorDetails.put(ErrorCode.CERTIFICATE_DOB_FORMAT_INVALID, new Object[] { dateFormat });
		}

		if (certificateDTO.getVisaApprovalDate() == null) {
			errorDetails.put(ErrorCode.CERTIFICATE_VISA_APPROVAL_DATE_FORMAT_INVALID, new Object[] { dateFormat });
		}

		if (certificateDTO.getVisaExpirationDate() == null) {
			errorDetails.put(ErrorCode.CERTIFICATE_VISA_EXPIRATION_DATE_FORMAT_INVALID, new Object[] { dateFormat });
		}

		if (!errorDetails.containsKey(ErrorCode.CERTIFICATE_DOB_FORMAT_INVALID)
				&& !errorDetails.containsKey(ErrorCode.CERTIFICATE_VISA_APPROVAL_DATE_FORMAT_INVALID)
				&& certificateDTO.getDateOfBirth().compareTo(certificateDTO.getVisaApprovalDate()) >= 0) {
			errorDetails.put(ErrorCode.DOB_GREATER_VISA_APPROVAL, null);
		}

		if ("NB".equals(certificateDTO.getTransactionType())
				&& !StringUtils.isEmpty(certificateDTO.getPreviousPolicyNo())) {
			errorDetails.put(ErrorCode.NOT_EMPTY_PREVIOUS_POLICY, null);
		}

		if ("REN".equals(certificateDTO.getTransactionType())
				&& StringUtils.isEmpty(certificateDTO.getPreviousPolicyNo())) {
			errorDetails.put(ErrorCode.EMPTY_PREVIOUS_POLICY, null);
		}

		// TODO: validate codified values

		return errorDetails;
	}

	@SuppressWarnings("unchecked")
	private FileSystemResource generateCertificate(CertificateDetails certificateDetails, String fileName)
			throws Exception {

		Period period = Period.between(
				certificateDetails.getVisaApprovalDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate(),
				certificateDetails.getVisaExpirationDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		int noOfMonths = (period.getYears() > 0 ? (period.getYears() * 12) + period.getMonths() : period.getMonths());

		ObjectMapper oMapper = new ObjectMapper();
		SimpleModule module = new SimpleModule();
		module.addSerializer(Date.class, new CustomDateSerializer(dateFormat));
		oMapper.registerModule(module);
		Map<String, String> certificateMap = oMapper.convertValue(certificateDetails, Map.class);
		certificateMap.put("visaNoOfMonths", String.valueOf(noOfMonths));
		return pdfGenerator.createPdf("certificate", certificateMap, fileName);
	}

	@Transactional(readOnly = true)
    public PolicyHistory getMasterPolicy(CertificateDTO certificateDTO) {
        String riskType = CommonConfig.getRiskType(certificateDTO.getEmployeeCategory());
        PolicyHistory masterPolicy = invokeRepo(() -> policyHistoryRepository.findMasterPolicy(riskType,
                                                                                               certificateDTO.getVisaApprovalDate()),
                                                "policyHistoryRepository.findMasterPolicy(riskTypeDefinition.getUID_VALUE(), certificateDTO.getVisaApprovalDate())");
        return masterPolicy;
	}
}
