package com.beyontec.mol.service;

import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.exception.ErrorCode;

public class BaseService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseService.class);

    protected <RESULT> RESULT invokeRepo(Supplier<RESULT> action,
                                         String operation) {
        try {
            LOGGER.debug(operation);
            return action.get();
        } catch (Exception e) {
            LOGGER.error(operation);
            LOGGER.error(e.getMessage());
            throw new ApplicationException(operation, e, ErrorCode.PERSIST_ERROR);
        }
    }

    protected <RESULT> RESULT invokeModelMapper(Supplier<RESULT> action,
                                                String operation) {
        try {
            LOGGER.debug(operation);
            return action.get();
        } catch (Exception e) {
            LOGGER.error(operation);
            LOGGER.error(e.getMessage());
            throw new ApplicationException(operation, e, ErrorCode.MODEL_MAPPER_ERROR);
        }
    }
}
