package com.beyontec.mol.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.common.util.RandomValueStringGenerator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.beyontec.mol.entity.User;
import com.beyontec.mol.entity.UserGroup;
import com.beyontec.mol.entity.UserGroupMenu;
import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.modal.Password;
import com.beyontec.mol.modal.UserDTO;
import com.beyontec.mol.modal.UserMenuDTO;
import com.beyontec.mol.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder userPasswordEncoder;

    @Transactional(readOnly = true)
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Transactional(readOnly = true)
    public User findUserById(Long id) {
        return userRepository.findOne(id);
    }

    @Transactional(readOnly = true)
    public UserDTO findUserByLoginId(String loginId) {

        User userDetails = userRepository.findByLoginId(loginId);

        ModelMapper modelMapper = new ModelMapper();
        UserDTO userDTO = modelMapper.map(userDetails, UserDTO.class);

        Set<String> userMenuList = new HashSet<String>();
        for (UserGroup userGroup : userDTO.getUserGroups()) {
            for (UserGroupMenu userMenu: userGroup.getUserGroupMenus()) {
                UserMenuDTO userMenuDTO = modelMapper.map(userMenu, UserMenuDTO.class);
                userMenuList.add(userMenuDTO.getName());
            }
        }

        userDTO.setUserMenu(userMenuList);
        return userDTO;
    }

    @Transactional
    public User createUser(User user) {

        RandomValueStringGenerator generator = new RandomValueStringGenerator(8);
        String password = generator.generate();
        user.setPassword(userPasswordEncoder.encode(password));
        return userRepository.save(user);
    }

    @Transactional
    public User updateUser(User user) {

        User rpUser = userRepository.findByLoginId(user.getLoginId());
        if (rpUser == null) {
            throw new ApplicationException(ErrorCode.ENTITY_NOT_FOUND);
        }
        rpUser.setFirstName(user.getFirstName());
        rpUser.setLastName(user.getFirstName());
        rpUser.setMailId(user.getMailId());
        rpUser.setMobileNumber(user.getMobileNumber());
        return userRepository.save(rpUser);
    }

    @Transactional
    public void deleteUser(String loginId) {

        User rpUser = userRepository.findByLoginId(loginId);
        if (rpUser == null) {
            throw new ApplicationException(ErrorCode.ENTITY_NOT_FOUND);
        }
        userRepository.deleteByLoginId(loginId);
    }

    @Transactional
	public User resetPassword(Password password) {

        User rpUser = userRepository.findByLoginId(password.getLoginId());
        if (rpUser == null) {
            throw new ApplicationException(ErrorCode.ENTITY_NOT_FOUND);
        }

        //Once password encryption is given, need to update this accordingly
        rpUser.setPassword(new BCryptPasswordEncoder(8).encode(password.getNewPassword()));
        rpUser.setLoginStatus("N");
        return userRepository.save(rpUser);
    }
}
