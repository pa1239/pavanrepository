package com.beyontec.mol.util;

public final class DMSConstants {

	// param variables
	public static final String ENTITY_REF_ID = "entityRefId";
	public static final String ENTITY_REF_TYPE = "entityRefType";
	public static final String REF_TYPE_CERTIFICATE = "Certificate";
	public static final String REF_TYPE_CLAIM = "Claim";
	public static final String GRID_FS_ID = "gridFSId";
	public static final String DOCUMENTS = "documents";
	public static final String METADATA = "metadata";
	public static final String PARTY_TYPE = "partyType";
	public static final String DOCUMENT_TYPE = "documentType";
	public static final String DESCRIPTION = "description";

	// uri
	public static final String UPLOAD_DOCUMENTS_URI = "/api/upload-multiple";
	public static final String GET_DOCUMENT_LIST = "/api/metadata?entityRefId={0}&entityRefType={1}";
	public static final String GET_DOCUMENT_CONTENT = "/api/document/{0}";
	public static final String DELETE_DOCUMENT_CONTENT = "/api/document/{0}";
}
