package com.beyontec.mol.util;

public final class AppConstants {
	
	public static final String CERTIFICATE_NO = "certificateNo";
	public static final String ERRORS = "errors";
	public static final String DOCUMENT_PATH = "documentPath";
}
