package com.beyontec.mol.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;
import com.lowagie.text.pdf.BaseFont;

@Component
public class PdfGenerator {
	@Autowired
	private TemplateEngine templateEngine;

	@SuppressWarnings("rawtypes")
	public FileSystemResource createPdf(String templateName, Map<?, ?> map, String fileName) throws Exception {

		// Set values to context
		Context ctx = new Context();
		if (map != null) {
			Iterator<?> itMap = map.entrySet().iterator();
			while (itMap.hasNext()) {
				Map.Entry pair = (Map.Entry) itMap.next();
				ctx.setVariable(pair.getKey().toString(), pair.getValue());
			}
		}

		String processedHtml = templateEngine.process(templateName, ctx);

		FileOutputStream os = null;
		try {
			File pdfFile = File.createTempFile(fileName, ".pdf");
			os = new FileOutputStream(pdfFile);

			ITextRenderer renderer = new ITextRenderer();
			renderer.getFontResolver().addFont("/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			renderer.setDocumentFromString(processedHtml);
			renderer.layout();
			renderer.createPDF(os, false);
			renderer.finishPDF();

			return new FileSystemResource(pdfFile);
		} finally {
			if (os != null) {
				try {
					os.close();
				} catch (IOException e) {
				}
			}
		}
	}
}