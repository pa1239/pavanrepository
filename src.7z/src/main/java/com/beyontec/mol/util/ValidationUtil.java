package com.beyontec.mol.util;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.beyontec.mol.entity.User;
import com.beyontec.mol.exception.ApplicationException;
import com.beyontec.mol.exception.ErrorCode;
import com.beyontec.mol.repository.UserRepository;

@Component
public class ValidationUtil {

    @Autowired
    private UserRepository userRepository;

    private String loginPassword;
    public void validateLoginCredentials(String userName, String password) {

        // Validating login credentials
        this.loginPassword = password;
        if (StringUtils.isEmpty(userName)) {
            throw new ApplicationException(ErrorCode.EMPTY_USERNAME);
        }

        if (StringUtils.isEmpty(password)) {
            throw new ApplicationException(ErrorCode.EMPTY_PASSWORD);
        }
    }

    public void validateUserDetails(User user) {

        if (null == user) {
            throw new ApplicationException(ErrorCode.USER_NOT_FOUND);
        } else {

            // Validating user default role
            String defaultRole = userRepository.findUserDefaultRole(user.getUserId());
            if ("N".equalsIgnoreCase(defaultRole)) {
                throw new ApplicationException(ErrorCode.NO_DEFAULT_ROLES);
            }

            // Validating user default division and department
            Set<String> divnAndDept = userRepository.findUserDefaultDivision(user.getUserId());
            if (!divnAndDept.contains("Y")) {
                throw new ApplicationException(ErrorCode.NO_DEFAULT_DIVISION_DEPARTMENT);
            }

            // Validating user default division and department
            String expirationDays = userRepository.findUserPwdExpiration(user.getCompanyId(), user.getPwdProfile());
            if ("0".equals(expirationDays)) {
                throw new ApplicationException(ErrorCode.EXPIRED_PASSWORD);
            }

            // Need to update once password encryption is given
            /*if (!user.getPassword().equals(new BCryptPasswordEncoder(8).encode(loginPassword))) {
                throw new ApplicationException(ErrorCode.INVALID_PASSWORD);
            }*/
        }
    }
}
