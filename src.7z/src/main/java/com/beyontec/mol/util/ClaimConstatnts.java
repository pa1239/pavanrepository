package com.beyontec.mol.util;

public enum ClaimConstatnts {
	CLAIM_NO("CLAIM NO"), CERTIFICATE_NO("CERTIFICATE NO"), EMIRATES_ID("EMIRATED ID"), BATCH_NO("BATCH NO"), CLAIM_LAUNCH_DATE("CLAIM LAUNCH DATE"),
    EMPLOYEE("EMPLOYEE"), EMPLOYEE_TYPE("EMPLOYEE TYPE"), EMPLOYEER_NAME("EMPLOYEER NAME"), CLAIM_STATUS("CLAIM STATUS");

    private final String name;

    private ClaimConstatnts(String s) {
        name = s;
    }

    public String toString() {
        return this.name;
    }
}