package com.beyontec.mol.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.beyontec.mol.modal.ClaimListingDTO;

public class ExcelExporter {

    public static byte[] convertJavaToExcel(List<ClaimListingDTO> claims) throws IOException {
        ByteArrayOutputStream baos = null;
        try {
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet sheet = workbook.createSheet("claims list");

            CellStyle cellStyle = workbook.createCellStyle();
            CreationHelper createHelper = workbook.getCreationHelper();
            short dateFormat = createHelper.createDataFormat().getFormat("yyyy-dd-MM");
            cellStyle.setDataFormat(dateFormat);

            sheet.setColumnWidth(0, 4000);
            sheet.setColumnWidth(4, 5000);
            sheet.setColumnWidth(5, 4000);
            sheet.setColumnWidth(6, 4000);

         // create header row
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue(ClaimConstatnts.CLAIM_NO.toString());
            header.createCell(1).setCellValue(ClaimConstatnts.CERTIFICATE_NO.toString());
            header.createCell(2).setCellValue(ClaimConstatnts.EMIRATES_ID.toString());
            header.createCell(3).setCellValue(ClaimConstatnts.BATCH_NO.toString());
            header.createCell(4).setCellValue(ClaimConstatnts.CLAIM_LAUNCH_DATE.toString());
            header.createCell(5).setCellValue(ClaimConstatnts.EMPLOYEE.toString());
            header.createCell(6).setCellValue(ClaimConstatnts.EMPLOYEE_TYPE.toString());
            header.createCell(7).setCellValue(ClaimConstatnts.EMPLOYEER_NAME.toString());
            header.createCell(8).setCellValue(ClaimConstatnts.CLAIM_STATUS.toString());

            int rownum = 1;

            for (ClaimListingDTO claim : claims) {
                Row row = sheet.createRow(rownum++);

                int cellnum = 0;
                row.createCell(cellnum++).setCellValue(claim.getClaimNo());
                row.createCell(cellnum++).setCellValue(claim.getCertificateNo());
                row.createCell(cellnum++).setCellValue(claim.getEmiratesId());
                row.createCell(cellnum++).setCellValue(claim.getBatchNo());
                Cell launchDateCell = row.createCell(cellnum++);
                launchDateCell.setCellStyle(cellStyle);
                launchDateCell.setCellValue(claim.getClaimLaunchDate());
                row.createCell(cellnum++).setCellValue(claim.getEmployee());
                row.createCell(cellnum++).setCellValue(claim.getEmployeeType());
                row.createCell(cellnum++).setCellValue(claim.getEmployerName());
                row.createCell(cellnum++).setCellValue(claim.getClaimStatus());
            }

            baos = new ByteArrayOutputStream();
            workbook.write(baos);
            workbook.close();
            return baos.toByteArray();
        } finally {
            baos.close();
        }
    }
}