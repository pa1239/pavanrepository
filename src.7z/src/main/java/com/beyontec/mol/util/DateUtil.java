package com.beyontec.mol.util;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class DateUtil {

    public static long getNumberOfDaysBetween(Date fromDate, Date toDate) {
        long diffInMs = toDate.getTime() - fromDate.getTime();
        return TimeUnit.DAYS.convert(diffInMs, TimeUnit.MILLISECONDS);
    }

    public static Date getCurrentDate() { return new Date(); }

    public static int getAge(Date dateOfBirth) {
        LocalDate localDateOfBirth = dateOfBirth.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        Period period = Period.between(localDateOfBirth, LocalDate.now());
        return period.getYears();
    }
}
