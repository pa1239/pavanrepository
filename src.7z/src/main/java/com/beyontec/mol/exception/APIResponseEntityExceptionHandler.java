package com.beyontec.mol.exception;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.tomcat.util.http.fileupload.FileUploadBase.SizeLimitExceededException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class APIResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger logger = LoggerFactory.getLogger(APIResponseEntityExceptionHandler.class);

	private final MessageSource messageSource;

	@Value("${spring.http.multipart.max-file-size}")
	private String fileSize;

	@Value("${spring.http.multipart.max-request-size}")
	private String totalFileSize;

	@Autowired
	public APIResponseEntityExceptionHandler(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	@ExceptionHandler(ApplicationException.class)
	public final ResponseEntity<ErrorResponse> handleApplicationException(ApplicationException ex, WebRequest request) {
		return getLocalizedErrorMessage(ex, ex.getErrorCode(), request);
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public final ResponseEntity<ErrorResponse> handleDBConstraintViolationException(DataIntegrityViolationException ex,
			WebRequest request) {
		return getLocalizedErrorMessage(ex, ErrorCode.DATABASE_CONSTRAINT_VIOLATION, request);
	}

	@ExceptionHandler(CannotCreateTransactionException.class)
	public final ResponseEntity<ErrorResponse> handleDBAccessException(CannotCreateTransactionException ex,
			WebRequest request) {
		return getLocalizedErrorMessage(ex, ErrorCode.DATABASE_ACCESS_ERROR, request);
	}

	@ExceptionHandler(RuntimeException.class)
	public final ResponseEntity<ErrorResponse> handleRuntimeException(RuntimeException ex, WebRequest request) {
		return getLocalizedErrorMessage(ex, ErrorCode.INTERNAL_SERVER_ERROR, request);
	}

	@ExceptionHandler(MultipartException.class)
	public final ResponseEntity<ErrorResponse> handleMultipartException(MultipartException ex, WebRequest request) {

		if (ex.getCause().getCause() instanceof SizeLimitExceededException) {
			return getLocalizedErrorMessage(ex, ErrorCode.DOCUMENTS_BEYOND_LIMIT, new Object[] { totalFileSize },
					request);
		}
		return getLocalizedErrorMessage(ex, ErrorCode.DOCUMENT_BEYOND_LIMIT, new Object[] { fileSize }, request);
	}

	@ExceptionHandler(ValidationException.class)
	public final ResponseEntity<ErrorDetailResponse> handleValidationException(ValidationException ex,
			WebRequest request) {

		List<ErrorDetail> errorDetails = new ArrayList<>();
		ErrorDetail errorDetail = null;

		for (Map.Entry<ErrorCode, Object[]> entry : ex.getErrorDetails().entrySet()) {

			errorDetail = new ErrorDetail(entry.getKey().getCode(),
					messageSource.getMessage(entry.getKey().getCode(), entry.getValue(), request.getLocale()));
			errorDetails.add(errorDetail);
		}

		return new ResponseEntity<ErrorDetailResponse>(new ErrorDetailResponse(errorDetails), HttpStatus.BAD_REQUEST);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		BindingResult result = ex.getBindingResult();
		List<String> errorMessages = result.getAllErrors().stream()
				.map(objectError -> messageSource.getMessage(objectError, request.getLocale()))
				.collect(Collectors.toList());
		return new ResponseEntity<Object>(new ErrorResponse(errorMessages), HttpStatus.BAD_REQUEST);
	}

	private ResponseEntity<ErrorResponse> getLocalizedErrorMessage(Exception ex, ErrorCode errorCode, Object[] arg,
			WebRequest request) {

		logger.error(ex.getMessage(), ex);
		return new ResponseEntity<ErrorResponse>(
				new ErrorResponse(Arrays.asList(
						messageSource.getMessage(String.valueOf(errorCode.getCode()), arg, request.getLocale()))),
				errorCode.getHttpStatus());
	}

	private ResponseEntity<ErrorResponse> getLocalizedErrorMessage(Exception ex, ErrorCode errorCode,
			WebRequest request) {
		return getLocalizedErrorMessage(ex, errorCode, null, request);
	}
}
