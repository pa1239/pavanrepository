package com.beyontec.mol.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.TaxProcess;

@Repository
public interface TaxProcessRepository extends JpaRepository<TaxProcess, Long> {

	TaxProcess findById(String id);

	@SuppressWarnings("unchecked")
	TaxProcess save(TaxProcess taxProcess);

}




