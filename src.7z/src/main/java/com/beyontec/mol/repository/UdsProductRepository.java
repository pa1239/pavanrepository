package com.beyontec.mol.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.UdsProduct;

@Repository
public interface UdsProductRepository extends JpaRepository<UdsProduct, Long> {

	UdsProduct findById(String id);

	@Query(value = "SELECT UP_ROUND_DEC FROM UDS_PRODUCT WHERE UP_COMP_ID = ?1 AND UP_PROD_ID = ?2", nativeQuery = true)
	UdsProduct findRoundDec(String companyId, String productId);

}
