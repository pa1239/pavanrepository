package com.beyontec.mol.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.UdsIdDefinition;

@Repository
public interface UdsIdDefinitionRepository extends JpaRepository<UdsIdDefinition, Long> {

	UdsIdDefinition findById(String id);

    @Query(value = "SELECT uid FROM UdsIdDefinition uid WHERE uid.id.companyId = :companyId")
    List<UdsIdDefinition> findByCompanyId(@Param("companyId") String companyId);

	@Query(value = "SELECT UID_VALUE FROM UDS_ID_DEFN WHERE UID_COMP_ID =?1 AND  UID_ID_TYP = 'MAP_ULR_RISK_TYP' AND UID_ID= ?2", nativeQuery = true)
	UdsIdDefinition findRiskTypeByEmpCategoryId(String companyId,String uid);

	// This query is for --ELN
	@Query(value = "SELECT UID_VALUE FROM UDS_ID_DEFN WHERE UID_COMP_ID =?1 AND UID_ID_TYP = 'DFLT_DATA' AND UID_ID='DFLT_UCD_ID_TYP1'", nativeQuery = true)
	UdsIdDefinition findCustomerDetails(String companyId);

	// This query is for --ESTC
	@Query(value = "SELECT UID_VALUE FROM UDS_ID_DEFN WHERE UID_COMP_ID =?1 AND UID_ID_TYP ='DFLT_DATA' AND UID_ID='DFLT_UCD_ID_TYP2'", nativeQuery = true)
	UdsIdDefinition findCustomerDetailsDefault(String companyId);

	
	// This query is TO GET ULM_CRU
	@Query(value = "SELECT UID_VALUE FROM UDS_ID_DEFN WHERE UID_COMP_ID =?1 AND  UID_ID_TYP ='DFLT_DATA' AND UID_ID='DFLT_ULM_CRU'", nativeQuery = true)
	UdsIdDefinition findCreatedUser(String companyId);

	//This query is ULI_DUE_DATE NEEDS TO BE CALUCLATED FROM ULI_BILL_DATE + UID_VALUE
	@Query(value = "SELECT UID_VALUE FROM UDS_ID_DEFN WHERE UID_COMP_ID =?1 AND UID_ID_TYP = 'DFLT_DATA' AND UID_ID = 'DFLT_ULI_DUE_DATE'", nativeQuery = true)
	UdsIdDefinition findDueDate(String companyId);


}
