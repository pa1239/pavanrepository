package com.beyontec.mol.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.ClaimWorkingEstimation;

@Repository
public interface ClaimWorkingDetailsRepository extends JpaRepository<ClaimWorkingEstimation, Long>{
    
    @Query(value = "SELECT CED_EST_TYP, CED_ULC_ID, CED_ULS_ID, CED_LOSS_ID, CED_DFLT_RATE FROM CUDS_EST_DEFN WHERE CED_PROD_ID= (SELECT CLF_PROD_ID FROM CTDS_LEVEL_FNOL WHERE CLF_SGS_ID =?1) AND CED_RISK_TYP=(SELECT CLR_RISK_TYP FROM CTDS_LEVEL_R WHERE CLR_CLF_SGS_ID =?2) AND CED_EST_TYP=?3 AND CED_LOSS_ID =?4", nativeQuery = true)
    public List<Object[]> getCUDS_EST_DEFNData(int fnolSgsId, int riskfnolSgsId, String payeeType, String lossType); 

}
