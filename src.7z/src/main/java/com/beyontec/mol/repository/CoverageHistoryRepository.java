package com.beyontec.mol.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.CoverageHistory;

@Repository
public interface CoverageHistoryRepository extends JpaRepository<CoverageHistory, Long> {

	CoverageHistory findById(String id);

	@SuppressWarnings("unchecked")
	CoverageHistory save(CoverageHistory coverageHistory);
	
	
	@Query(value = "SELECT ULC_MST_ID, ULC_SI_LIMIT, ULC_SINGLE_LIMIT, ULC_SI_LIMIT_BC, ULC_SINGLE_LIMIT_BC FROM UHDS_LEVEL_C WHERE ULC_ULM_SGS_ID =?1 AND ULC_AMND_VER_NO =?2 AND ULC_ULR_ID = (SELECT ULR_ID FROM UHDS_LEVEL_R WHERE ULR_ULM_SGS_ID = ULC_ULM_SGS_ID AND ULR_AMND_VER_NO = ULC_AMND_VER_NO AND ULR_RISK_TYP =?3)", nativeQuery = true)
	CoverageHistory findCoverageBySgsIdAndAmdVersionNo(String sgsId, String amdVersionNo, String riskType);
	

}


