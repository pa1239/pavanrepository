package com.beyontec.mol.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.PolicyMain;

@Repository
public interface PolicyMainRepository extends PolicyBaseRepository<PolicyMain> {

    @Query(value = "SELECT p FROM PolicyMain p WHERE p.number = :prevPolicyNumber AND p.status = :status")
    public PolicyMain findByPrevPolicyNo(@Param("prevPolicyNumber") String prevPolicyNumber,
                                         @Param("status") String status);

    public PolicyMain findByNumber(String certificateNo);
}
