package com.beyontec.mol.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.ClaimTransactionEstimation;

@Repository
public interface ClaimTransactionEstimationRepository extends JpaRepository<ClaimTransactionEstimation, Long> {
	
	@Query(value = "SELECT CLE_LOSS_ID FROM CTDS_LEVEL_E WHERE CLE_CLF_SGS_ID = ?1", nativeQuery = true)
	public String getPaymentType(int fnolSgsId);
	
	public List<ClaimTransactionEstimation> findByFnolSgsId(int sgsId);

}
