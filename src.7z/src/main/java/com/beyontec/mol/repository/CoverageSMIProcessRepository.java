package com.beyontec.mol.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.CoverageSMIProcess;

@Repository
public interface CoverageSMIProcessRepository extends JpaRepository<CoverageSMIProcess, Long> {

	CoverageSMIProcess findById(String id);

	@SuppressWarnings("unchecked")
	CoverageSMIProcess save(CoverageSMIProcess coverageSMIProcess);

}

