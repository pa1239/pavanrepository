package com.beyontec.mol.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.beyontec.mol.entity.ClaimTransactionRisk;

public interface ClaimTransactionRiskRepository extends JpaRepository<ClaimTransactionRisk, Long>{

}
