package com.beyontec.mol.repository;


import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.RiskAdditionalHistory;

@Repository
public interface RiskAdditionalHistoryRepository extends RiskAdditionalBaseRepository<RiskAdditionalHistory> {
}
