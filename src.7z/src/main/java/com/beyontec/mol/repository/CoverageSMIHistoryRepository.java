package com.beyontec.mol.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.CoverageSMIHistory;

@Repository
public interface CoverageSMIHistoryRepository extends JpaRepository<CoverageSMIHistory, Long> {

	CoverageSMIHistory findById(String id);

	@SuppressWarnings("unchecked")
	CoverageSMIHistory save(CoverageSMIHistory coverageSMIHistory);

	@Query(value = "SELECT ULCS_ULC_MST_ID, ULCS_ULS_MST_ID, ULCS_SI, ULCS_PREM, ULCS_ANNUAL_PREM, ULCS_UE_PREM, ULCS_PR_PREM, ULCS_ACNT_FLAG, ULCS_RATE_PER, ULCS_MOD_RATE, ULCS_RATE, ULCS_TXN_PREM, ULCS_SINGLE_LIMIT, ULCS_SI_BC, ULCS_SINGLE_LIMIT_BC, ULCS_PREM_BC, ULCS_ANNUAL_PREM_BC, ULCS_UE_PREM_BC, ULCS_PR_PREM_BC, ULCS_TXN_PREM_BC, ULCS_CUR_ID, ULCS_CUR_X_RATE, ULCS_SI_RATE FROM UHDS_LEVEL_CS WHERE ULCS_ULM_SGS_ID =?1 ULM_SGS_ID AND ULCS_AMND_VER_NO =?2 ULM_AMND_NO AND ULCS_ULR_ID = (SELECT ULR_ID FROM UHDS_LEVEL_R WHERE ULR_ULM_SGS_ID = ULCS_ULM_SGS_ID AND ULR_AMND_VER_NO = ULCS_AMND_VER_NO AND ULR_RISK_TYP =?3)", nativeQuery = true)
	CoverageSMIHistory findCoverageHistoryBySgsIdAndAmdVersionNo(String sgsId, String amdVersionNo, String riskType);

}


