package com.beyontec.mol.repository;


import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.PolicyHistory;

@Repository
public interface PolicyHistoryRepository extends PolicyBaseRepository<PolicyHistory> {

    @Query(value = "SELECT * FROM UHDS_LEVEL_M "
                   + "WHERE (ULM_SGS_ID, ULM_AMND_VER_NO) = (SELECT ULM_SGS_ID, MAX(ULM_AMND_VER_NO) FROM UHDS_LEVEL_M, UHDS_LEVEL_R "
                                                           + "WHERE ULM_SGS_ID = ULR_ULM_SGS_ID "
                                                           + "AND ULR_RISK_TYP = :riskType "
                                                           + "AND :visaApprovalDate BETWEEN NVL (ULM_AMND_FMD, ULM_FMD) AND NVL(ULM_AMND_TOD, ULM_TOD)	"
                                                           + "GROUP BY ULM_SGS_ID) "
                   + "AND ULM_BTYP_ID = 'O' and ULM_STATUS = 'CTP'", nativeQuery = true)
    PolicyHistory findMasterPolicy(@Param("riskType") String riskType,
                                   @Param("visaApprovalDate") Date visaApprovalDate);
}
