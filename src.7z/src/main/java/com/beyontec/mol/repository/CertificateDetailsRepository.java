package com.beyontec.mol.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.CertificateDetails;

@Repository
public interface CertificateDetailsRepository extends JpaRepository<CertificateDetails, Long> {

	CertificateDetails findByEmiratesIdAndErrType(String emiratesId, String errorType); //TODO : also nedd to add visa/labour ref No
	
	CertificateDetails findByLabourReferenceNoAndCertificateNumberAndErrType(String visaRefNo, String certificateNo, String errorType);

    CertificateDetails findByCertificateNumber(String certificateNumber);
}
