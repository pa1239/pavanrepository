package com.beyontec.mol.repository;

import com.beyontec.mol.entity.CustomerDetailsHistory;

public interface CustomerDetailsHistoryRepository extends CustomerDetailsBaseRepo<CustomerDetailsHistory> {
}
