package com.beyontec.mol.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.beyontec.mol.entity.TaxHistory;

@Repository
public interface TaxHistoryRepository extends JpaRepository<TaxHistory, Long> {

	TaxHistory findById(String id);

	@SuppressWarnings("unchecked")
	TaxHistory save(TaxHistory taxHistory);
	
	

	@Query(value = "SELECT ULTCF_TYP, ULTCF_MST_ID, ULTCF_RATE, ULTCF_RATE_PER, ULTCF_ORD_NO, ULTCF_APPL_ORD_NO, ULTCF_SUB_TYP, ULTCF_ID, ULTCF_CUR_ID, ULTCF_CUR_X_RATE,ULTCF_ADJ_RATE, ULTCF_ADJ_RATE_PER	FROM UHDS_LEVEL_TCF WHERE ULTCF_ULM_SGS_ID =?1 AND ULTCF_AMND_VER_NO =?2", nativeQuery = true)
	TaxHistory findMasterData(String companyId);
		
		
	

}





