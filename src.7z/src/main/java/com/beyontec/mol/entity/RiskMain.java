package com.beyontec.mol.entity;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.beyontec.mol.config.CommonConfig;

@Entity
@Table(name = "UPDS_LEVEL_R")
@EntityListeners(AuditingEntityListener.class)
public class RiskMain extends RiskBase {

    private static final String DEFAULT_ID = "1";
    private void loadCommonDefaults() {
        this.id = DEFAULT_ID;
        this.additionalEntityYn = CommonConfig.FLAG_NO;
        this.oseAmendmentVersionNumber = CommonConfig.DEFAULT_VERSION_NUMBER;
    }

    public void loadDefaults() {
        loadCommonDefaults();
        this.recordType = CommonConfig.RECORD_TYPE_N;
    }

    public void loadFromCertificateDetails(CertificateDetails certificateDetails) {
        this.riskType = CommonConfig.getRiskType(certificateDetails.getEmployeeCategory());

        this.flex01 = certificateDetails.getWorkerNameEn();
        this.flex01Desc = certificateDetails.getWorkerNameEn();

        this.flex02 = certificateDetails.getEmiratesId();
        this.flex02Desc = certificateDetails.getEmiratesId();

        this.flex03 = certificateDetails.getEmployeeCategory();
        this.flex03Desc = certificateDetails.getEmployeeCategory();
    }

    public void loadFromPolicyMain(PolicyMain policyMain) {
        this.fromDate = policyMain.getFromDate();
        this.toDate = policyMain.getToDate();
        this.ulmSgsId = policyMain.getSgsId();
        this.amendmentVersionNumber = policyMain.getAmendmentVersionNumber();
        this.amendmentFromDate = policyMain.getAmendmentFromDate();
        this.amendmentToDate = policyMain.getAmendmentToDate();
        this.companyId = policyMain.getCompanyId();
    }

    public void loadFromMasterRisk(RiskHistory masterRisk) {
        this.curId = masterRisk.getCurId();
        this.curXRate = masterRisk.getCurXRate();
    }
}
