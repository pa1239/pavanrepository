package com.beyontec.mol.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.beyontec.mol.config.CommonConfig;
import com.beyontec.mol.util.DateUtil;

@Entity
@Table(name = "UPDS_LEVEL_M")
@EntityListeners(AuditingEntityListener.class)
public class PolicyMain extends PolicyBase {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sgs_id_generator")
    @SequenceGenerator(name="sgs_id_generator", sequenceName = "SEQ_ULM_SGS_ID")
    @Column(name = "ULM_SGS_ID") private Long sgsId;

    public Long getSgsId() {
        return sgsId;
    }

    public void setSgsId(Long sgsId) {
        this.sgsId = sgsId;
    }

    public void loadDefaults() {
        loadCommonDefaults();
        this.recordType = CommonConfig.RECORD_TYPE_N;
        this.amendmentVersionNumber = CommonConfig.DEFAULT_VERSION_NUMBER;
    }

    private static final String BTYPE_ID_POLICY = "C";
    private static final String DEFAULT_STATUS = "CTP";
    private static final String DEFAULT_TEMPLATE_TYPE = "D";

    private void loadCommonDefaults() {
        this.type = CommonConfig.BTYPE_POLICY;
        this.bTypeId = BTYPE_ID_POLICY;
        this.status = DEFAULT_STATUS;
        this.itrVersionNumber = CommonConfig.DEFAULT_VERSION_NUMBER;
        this.fltYn = CommonConfig.FLAG_NO;
        this.oseYn = CommonConfig.FLAG_NO;
        this.templateType = DEFAULT_TEMPLATE_TYPE;
        this.approvalDate = DateUtil.getCurrentDate();
        this.createdDate = DateUtil.getCurrentDate();
    }

    public void loadFromMasterPolicy(PolicyHistory masterPolicy) {
        this.companyId = masterPolicy.companyId;
        this.divnId = masterPolicy.divnId;
        this.departmentId = masterPolicy.departmentId;
        this.productId = masterPolicy.productId;
        this.periodUnit = masterPolicy.periodUnit;
        this.premiumCalculationType = masterPolicy.premiumCalculationType;
        this.bSourceId = masterPolicy.bSourceId;
        this.customerId = masterPolicy.customerId;
        this.addressReferenceId = masterPolicy.addressReferenceId;
        this.contactReferenceId = masterPolicy.contactReferenceId;
        this.customerAccountId = masterPolicy.customerAccountId;
        this.periodType = masterPolicy.periodType;
        this.payorId = masterPolicy.payorId;
        this.payorAddressRefId = masterPolicy.payorAddressRefId;
        this.uiInstId = masterPolicy.uiInstId;
        this.payorType = masterPolicy.payorType;
        this.term = masterPolicy.term;
        this.customerType = masterPolicy.customerType;
        this.prmCurr = masterPolicy.prmCurr;
        this.prmCurrId = masterPolicy.prmCurrId;
        this.prmCurrXRate = masterPolicy.prmCurrXRate;
        this.eqType = masterPolicy.eqType;

        this.cName = masterPolicy.cName;
        this.cFirstName = masterPolicy.cFirstName;
        this.cMiddleName = masterPolicy.cMiddleName;
        this.cLastName = masterPolicy.cLastName;
        this.cAddress1 = masterPolicy.cAddress1;
        this.cAddress2 = masterPolicy.cAddress2;
        this.cAddress3 = masterPolicy.cAddress3;
        this.cAddress4 = masterPolicy.cAddress4;
        this.cPinCode = masterPolicy.cPinCode;
        this.cCity = masterPolicy.cCity;
        this.cState = masterPolicy.cState;
        this.cCountry = masterPolicy.cCountry;

        this.prefixName = masterPolicy.prefixName;
        this.prefixNameBl = masterPolicy.prefixNameBl;

        this.cNameBl = masterPolicy.cNameBl;
        this.cFirstNameBl = masterPolicy.cFirstNameBl;
        this.cLastNameBl = masterPolicy.cLastNameBl;

        this.cpyPhoneNumber = masterPolicy.cpyPhoneNumber;
        this.cpyMobileNumber = masterPolicy.cpyMobileNumber;
        this.cFaxNumber = masterPolicy.cFaxNumber;
        this.cpyEmailId = masterPolicy.cpyEmailId;

        this.siCurr = masterPolicy.siCurr;
        this.siCurrId = masterPolicy.siCurrId;
        this.siXRate = masterPolicy.siXRate;

        this.mstRefNumber = masterPolicy.number;
        this.mstRefSgsId = masterPolicy.getSgsId();
        // FIXME: fix the sql validator exceptio and uncomment
//        this.mstRefAmendmentVersionNumber = masterPolicy.mstRefAmendmentVersionNumber;
    }

    private static final String SUFFIX_LEVEL2_ITR_NO = "/0";
    public void loadFromCertificateDetails(CertificateDetails certificateDetails) {
        this.issuedDate = certificateDetails.getReqInDate();
        this.fromDate = certificateDetails.getVisaApprovalDate();
        this.toDate = certificateDetails.getVisaExpirationDate();
        this.period = certificateDetails.getVisaPeriod();

        this.number = this.level2Number = certificateDetails.getCertificateNumber();
        this.level2ItrNumber = certificateDetails.getCertificateNumber() + SUFFIX_LEVEL2_ITR_NO;
    }

    public void loadFromCustomerDetails(CustomerDetailsMain customerDetails) {
        this.insuredId = String.valueOf(customerDetails.getId());
        this.insuredName = customerDetails.getName();
    }

    public void loadFromUdsIdDefinition() {
        String defaultCreatedUser = CommonConfig.getUdsIdDefinitionValue(CommonConfig.UDS_ID_DEF_TYPE_DEFAULT_DATA,
                                                                         CommonConfig.UDS_ID_DEF_ID_DEFAULT_CREATED_USER);
        this.createdUser = defaultCreatedUser;
        this.apu = defaultCreatedUser;
    }

    public void loadFromPrevPolicy(PolicyMain prevCertificatePolicy) {
        if (prevCertificatePolicy == null) {
            return;
        }

        this.renPolNumber = prevCertificatePolicy.number;
        this.renOrgSgsId = prevCertificatePolicy.getSgsId();
        this.renSequenceNumber = prevCertificatePolicy.getRenSequenceNumber() + 1;
    }

    public void loadFromProductAppBusType(ProductAppBusType productAppBusType) {
        this.templateId = productAppBusType.getSgsId();
    }
}
