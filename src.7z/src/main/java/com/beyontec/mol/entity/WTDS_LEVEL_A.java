package com.beyontec.mol.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

//@Entity
//@Table(name = "WTDS_LEVEL_A")
public class WTDS_LEVEL_A {

	@Id
	@Column(name = "WLA_SGS_ID")
	private Long activitySGSId;
	@Column(name = "WLA_COMP_ID")
	private String companyId;
	@Column(name = "WLA_MODULE")
	private String module;
	@Column(name = "WLA_ACT_ID")
	private String activityId;
	@Column(name = "WLA_PROCESS_ID")
	private String WLA_PROCESS_ID;
	@Column(name = "WLA_CUST_ID")
	private String customerId;
	@Column(name = "WLA_PROD_ID")
	private String productId;
	@Column(name = "WLA_TXN_REF")
	private Long fnolSgsId;
	@Column(name = "WLA_TXN_SREF")
	private Long WLA_TXN_SREF;
	@Column(name = "WLA_TXN_REF_NO")
	private String fnolRef;
	@Column(name = "WLA_TXN_SREF_NO")
	private String claimRef;
	@Column(name = "WLA_TXNU")
	private String assignedUser;
	@Column(name = "WLA_CRU")
	private String createdUser;
	@Column(name = "WAL_CRD")
	private Date createdDate;
	@Column(name = "WLA_UPU")
	private String upDatedUser;
	@Column(name = "WLA_UPD")
	private Date upDatedDate;
	@Column(name = "WLA_ACT_FMD")
	private Date activityFrom;
	@Column(name = "WLA_ACT_DUED")
	private Date activiityDueDate;
	@Column(name = "WLA_ACT_COMD")
	private Date activityCompletedDate;
	@Column(name = "WLA_STATUS")
	private String activityStatus;
	@Column(name = "WLA_NLM_SGS_ID")
	private Long WLA_NLM_SGS_ID;
	@Column(name = "WLA_UBH_BR_ID")
	private String WLA_UBH_BR_ID;
	@Column(name = "WLA_VFLEX_01")
	private String WLA_VFLEX_01;
	@Column(name = "WLA_VFLEX_02")
	private String WLA_VFLEX_02;
	@Column(name = "WLA_VFLEX_03")
	private String WLA_VFLEX_03;
	@Column(name = "WLA_VFLEX_04")
	private String WLA_VFLEX_04;
	@Column(name = "WLA_VFLEX_05")
	private String WLA_VFLEX_05;
	@Column(name = "WLA_DFLEX_01")
	private Date WLA_DFLEX_01;
	@Column(name = "WLA_DFLEX_02")
	private Date WLA_DFLEX_02;
	@Column(name = "WLA_DFLEX_03")
	private Date WLA_DFLEX_03;
	@Column(name = "WLA_DFLEX_04")
	private Date WLA_DFLEX_04;
	@Column(name = "WLA_DFLEX_05")
	private Date WLA_DFLEX_05;
	@Column(name = "WLA_NFLEX_01")
	private Long WLA_NFLEX_01;
	@Column(name = "WLA_NFLEX_02")
	private Long WLA_NFLEX_02;
	@Column(name = "WLA_LEVEL1_REF")
	private Long level1Ref;
	@Column(name = "WLA_LEVEL2_REF")
	private String level2Ref;
	@Column(name = "WLA_LEVEL3_REF")
	private Long level3Ref;
	@Column(name = "WLA_LEVEL4_REF")
	private Long WLA_LEVEL4_REF;
	@Column(name = "WLA_LEVEL5_REF")
	private Long WLA_LEVEL5_REF;
	@Column(name = "WLA_LEVEL6_REF")
	private String level6Ref;
	@Column(name = "WLA_LEVEL7_REF")
	private String WLA_LEVEL7_REF;
	@Column(name = "WLA_REF_TYP")
	private String WLA_REF_TYP;
	@Column(name = "WLA_LEVEL8_REF")
	private Long WLA_LEVEL8_REF;
	@Column(name = "WLA_TXN_AUG_ID")
	private String assignedGroupId;
	@Column(name = "WLA_ACTU")
	private String actedUserOnTheTransaction;
	@Column(name = "WLA_USED_FOR")
	private String WLA_USED_FOR;
	@Column(name = "WLA_DIVN_ID")
	private String WLA_DIVN_ID;
	@Column(name = "WLA_EREF_SGS_ID")
	private Long WLA_EREF_SGS_ID;
}

