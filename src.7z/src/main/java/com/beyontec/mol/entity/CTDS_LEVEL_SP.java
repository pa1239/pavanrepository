package com.beyontec.mol.entity;

import javax.persistence.Column;
import javax.persistence.Id;

//@Entity
//@Table(name = "CTDS_LEVEL_SP")
public class CTDS_LEVEL_SP {

	@Id
	@Column(name = "CLSP_CLS_SGS_ID")
	private Long settlementSgsId;
	@Column(name = "CLSP_CLF_SGS_ID")
	private Long fnolSgsId;
	@Column(name = "CLSP_CLE_SGS_ID")
	private Long estimateSgsId;
	@Column(name = "CLSP_PAYEE_NAME")
	private String payeeName;
	@Column(name = "CLSP_PAYEE_ENT_TYP")
	private String payeeEntryType;
	@Column(name = "CLSP_MAIN_PAYEE")
	private String mainPayeeYN;
	@Column(name = "CLSP_DISP_ORD_NO")
	private Integer displayOrderNo;
	@Column(name = "CLSP_PAY_OPTION")
	private String paymentOption;
	@Column(name = "CLSP_CUST_TYP")
	private String customerType;
	@Column(name = "CLSP_ADDRESS1")
	private String payeeAdress1;
	@Column(name = "CLSP_ADDRESS2")
	private String payeeAdress2;
	@Column(name = "CLSP_ADDRESS3")
	private String payeeAdress3;
	@Column(name = "CLSP_ADDRESS4")
	private String payeeAdress4;
	@Column(name = "CLSP_PIN_CODE")
	private String pincode;
	@Column(name = "CLSP_CITY")
	private String city;
	@Column(name = "CLSP_STATE")
	private String state;
	@Column(name = "CLSP_COUNTRY_ID")
	private String country;
	@Column(name = "CLSP_SSN_ID")
	private String CLSP_SSN_ID;
	@Column(name = "CLSP_PAYEE_ID")
	private String payeeId;
	@Column(name = "CLSP_COMP_ID")
	private String companyId;

}
