package com.beyontec.mol.entity;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "UPDS_LEVEL_I")
@EntityListeners(AuditingEntityListener.class)
public class InstallmentsProcess {

	@Id
	@GeneratedValue
	private Long id;

	private String ULI_ULM_SGS_ID;
	private String ULI_AMND_VER_NO;
	private String ULI_ULM_AMND_NO;
	private String ULI_INST_NO;
	private String ULI_BILL_DATE;
	private String ULI_DUE_DATE;
	private String ULI_INST_AMT;
	private String ULI_REC_TYP;
	private String ULI_CUR_ID;
	private String ULI_CUR_X_RATE;
	private String ULI_INST_AMT_BC;
	private String ULI_TCF_AMT;
	private String ULI_TCF_AMT_BC;
	private String ULI_INST_ID;
	private String ULI_ACCT_CUST_ID;
	private String ULI_COMP_ID;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getULI_ULM_SGS_ID() {
		return ULI_ULM_SGS_ID;
	}

	public void setULI_ULM_SGS_ID(String uLI_ULM_SGS_ID) {
		ULI_ULM_SGS_ID = uLI_ULM_SGS_ID;
	}

	public String getULI_AMND_VER_NO() {
		return ULI_AMND_VER_NO;
	}

	public void setULI_AMND_VER_NO(String uLI_AMND_VER_NO) {
		ULI_AMND_VER_NO = uLI_AMND_VER_NO;
	}

	public String getULI_ULM_AMND_NO() {
		return ULI_ULM_AMND_NO;
	}

	public void setULI_ULM_AMND_NO(String uLI_ULM_AMND_NO) {
		ULI_ULM_AMND_NO = uLI_ULM_AMND_NO;
	}

	public String getULI_INST_NO() {
		return ULI_INST_NO;
	}

	public void setULI_INST_NO(String uLI_INST_NO) {
		ULI_INST_NO = uLI_INST_NO;
	}

	public String getULI_BILL_DATE() {
		return ULI_BILL_DATE;
	}

	public void setULI_BILL_DATE(String uLI_BILL_DATE) {
		ULI_BILL_DATE = uLI_BILL_DATE;
	}

	public String getULI_DUE_DATE() {
		return ULI_DUE_DATE;
	}

	public void setULI_DUE_DATE(String uLI_DUE_DATE) {
		ULI_DUE_DATE = uLI_DUE_DATE;
	}

	public String getULI_INST_AMT() {
		return ULI_INST_AMT;
	}

	public void setULI_INST_AMT(String uLI_INST_AMT) {
		ULI_INST_AMT = uLI_INST_AMT;
	}

	public String getULI_REC_TYP() {
		return ULI_REC_TYP;
	}

	public void setULI_REC_TYP(String uLI_REC_TYP) {
		ULI_REC_TYP = uLI_REC_TYP;
	}

	public String getULI_CUR_ID() {
		return ULI_CUR_ID;
	}

	public void setULI_CUR_ID(String uLI_CUR_ID) {
		ULI_CUR_ID = uLI_CUR_ID;
	}

	public String getULI_CUR_X_RATE() {
		return ULI_CUR_X_RATE;
	}

	public void setULI_CUR_X_RATE(String uLI_CUR_X_RATE) {
		ULI_CUR_X_RATE = uLI_CUR_X_RATE;
	}

	public String getULI_INST_AMT_BC() {
		return ULI_INST_AMT_BC;
	}

	public void setULI_INST_AMT_BC(String uLI_INST_AMT_BC) {
		ULI_INST_AMT_BC = uLI_INST_AMT_BC;
	}

	public String getULI_TCF_AMT() {
		return ULI_TCF_AMT;
	}

	public void setULI_TCF_AMT(String uLI_TCF_AMT) {
		ULI_TCF_AMT = uLI_TCF_AMT;
	}

	public String getULI_TCF_AMT_BC() {
		return ULI_TCF_AMT_BC;
	}

	public void setULI_TCF_AMT_BC(String uLI_TCF_AMT_BC) {
		ULI_TCF_AMT_BC = uLI_TCF_AMT_BC;
	}

	public String getULI_INST_ID() {
		return ULI_INST_ID;
	}

	public void setULI_INST_ID(String uLI_INST_ID) {
		ULI_INST_ID = uLI_INST_ID;
	}

	public String getULI_ACCT_CUST_ID() {
		return ULI_ACCT_CUST_ID;
	}

	public void setULI_ACCT_CUST_ID(String uLI_ACCT_CUST_ID) {
		ULI_ACCT_CUST_ID = uLI_ACCT_CUST_ID;
	}

	public String getULI_COMP_ID() {
		return ULI_COMP_ID;
	}

	public void setULI_COMP_ID(String uLI_COMP_ID) {
		ULI_COMP_ID = uLI_COMP_ID;
	}

}
