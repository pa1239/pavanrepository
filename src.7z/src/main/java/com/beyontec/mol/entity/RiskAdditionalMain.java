package com.beyontec.mol.entity;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.beyontec.mol.config.CommonConfig;
import com.beyontec.mol.util.DateUtil;

@Entity
@Table(name = "UPDS_LEVEL_RMBR")
@EntityListeners(AuditingEntityListener.class)
public class RiskAdditionalMain extends RiskAdditionalBase {

    private void loadCommonDefaults() {
        this.oseYn = CommonConfig.FLAG_NO;
    }

    public void loadDefaults() {
        loadCommonDefaults();
        this.recordType = CommonConfig.RECORD_TYPE_N;
    }

    public void loadFromRiskMain(RiskMain riskMain) {
        this.ulmSgsId = riskMain.getUlmSgsId();
        this.ulrId = riskMain.getId();
        this.id = riskMain.getId();
        this.amendmentVersionNumber = riskMain.amendmentVersionNumber;
        this.end = riskMain.getFromDate();
        this.exd = riskMain.getToDate();
        this.companyId = riskMain.companyId;
    }

    public void loadFromCertificateDetails(CertificateDetails certificateDetails) {
        this.name = certificateDetails.getWorkerNameEn();
        this.nameBl = certificateDetails.getWorkerNameAr();
        this.dateOfBirth = certificateDetails.getDateOfBirth();
        this.category = certificateDetails.getEmployeeCategory();
        this.designation = String.valueOf(certificateDetails.getMohreJobId());
        this.nationality = certificateDetails.getNationality();
        this.salary = certificateDetails.getSalary();
        this.salaryBc = certificateDetails.getSalary();
        this.age = (long) DateUtil.getAge(certificateDetails.getDateOfBirth());
        this.maritalStatus = certificateDetails.getMaritalStatus();
        this.gender = certificateDetails.getGender();
        this.cardId = certificateDetails.getLabourReferenceNo();
        this.licenseRefNumber = certificateDetails.getLabourReferenceNo();
        this.passportType = certificateDetails.getPassportType();
        this.passport = certificateDetails.getPassportNo();
        this.nationality = certificateDetails.getNationality();
        this.emirateId = certificateDetails.getEmiratesId();
        this.countryOfBirth = certificateDetails.getCountryOfBirth();
        this.fileNumber = certificateDetails.getFileNo();
    }

    public void loadFromCertificatePolicy(PolicyMain certificatePolicy) {
        this.sponserId = certificatePolicy.getInsuredId();
    }
}
