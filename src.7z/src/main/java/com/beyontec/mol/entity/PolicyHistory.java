package com.beyontec.mol.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.beyontec.mol.config.CommonConfig;

@Entity
@Table(name = "UHDS_LEVEL_M")
@EntityListeners(AuditingEntityListener.class)
public class PolicyHistory extends PolicyBase {
    @Id @Column(name = "ULM_SGS_ID") private Long sgsId;

    public Long getSgsId() {
        return sgsId;
    }

    public void setSgsId(Long sgsId) {
        this.sgsId = sgsId;
    }

    public void loadDefaults() {
        this.recordType = CommonConfig.RECORD_TYPE_I;
    }
}
