package com.beyontec.mol.modal;

public class PaymentDetails {

	private String requestedPersonName;
	private String cover;
	private int amount;
	private int settledAmount;
	private int outstandingAmount;

	public String getRequestedPersonName() {
		return requestedPersonName;
	}

	public void setRequestedPersonName(String requestedPersonName) {
		this.requestedPersonName = requestedPersonName;
	}

	public String getCover() {
		return cover;
	}

	public void setCover(String cover) {
		this.cover = cover;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getSettledAmount() {
		return settledAmount;
	}

	public void setSettledAmount(int settledAmount) {
		this.settledAmount = settledAmount;
	}

	public int getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(int outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

}
