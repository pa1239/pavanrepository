package com.beyontec.mol.modal;

import java.util.List;

public class ClaimRegistartionListingDTO {

    private ClaimDetails claimDetails;
    private GeneralDetails generalDetails;
    private SponsorDetails sponsorDetails;
    private WorkerInfo workerInfo;
    private LossDetails lossDetails;
    private List<PriorClaims> priorClaims;

    public ClaimDetails getClaimDetails() {
        return claimDetails;
    }

    public void setClaimDetails(ClaimDetails claimDetails) {
        this.claimDetails = claimDetails;
    }

    public GeneralDetails getGeneralDetails() {
        return generalDetails;
    }

    public void setGeneralDetails(GeneralDetails generalDetails) {
        this.generalDetails = generalDetails;
    }

    public SponsorDetails getSponsorDetails() {
        return sponsorDetails;
    }

    public void setSponsorDetails(SponsorDetails sponsorDetails) {
        this.sponsorDetails = sponsorDetails;
    }

    public WorkerInfo getWorkerInfo() {
        return workerInfo;
    }

    public void setWorkerInfo(WorkerInfo workerInfo) {
        this.workerInfo = workerInfo;
    }

    public LossDetails getLossDetails() {
        return lossDetails;
    }

    public void setLossDetails(LossDetails lossDetails) {
        this.lossDetails = lossDetails;
    }

	public List<PriorClaims> getPriorClaims() {
		return priorClaims;
	}

	public void setPriorClaims(List<PriorClaims> priorClaims) {
		this.priorClaims = priorClaims;
	}

}
