package com.beyontec.mol.modal;

import org.hibernate.validator.constraints.NotBlank;

public class DMSDocumentMetadataDTO {

	@NotBlank
	private String entityRefId;

	@NotBlank
	private String entityRefType;

	private String partyType;

	private String documentType;

	private String description;
	
	public DMSDocumentMetadataDTO() {
		
	}

	public DMSDocumentMetadataDTO(String entityRefId, String entityRefType) {
		this.entityRefId = entityRefId;
		this.entityRefType = entityRefType;
	}

	public DMSDocumentMetadataDTO(String entityRefId, String entityRefType, String partyType, String documentType,
			String description) {
		this.entityRefId = entityRefId;
		this.entityRefType = entityRefType;
		this.partyType = partyType;
		this.documentType = documentType;
		this.description = description;
	}

	public String getEntityRefId() {
		return entityRefId;
	}

	public void setEntityRefId(String entityRefId) {
		this.entityRefId = entityRefId;
	}

	public String getEntityRefType() {
		return entityRefType;
	}

	public void setEntityRefType(String entityRefType) {
		this.entityRefType = entityRefType;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
