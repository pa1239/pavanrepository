package com.beyontec.mol.modal;

public class GeneralDetails {

    private String masterPolicyNo;
    private String certificateNo;
    private String certificatePeriod;
    private String productName;

    public String getMasterPolicyNo() {
        return masterPolicyNo;
    }

    public void setMasterPolicyNo(String masterPolicyNo) {
        this.masterPolicyNo = masterPolicyNo;
    }

    public String getCertificateNo() {
        return certificateNo;
    }

    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }

    public String getCertificatePeriod() {
        return certificatePeriod;
    }

    public void setCertificatePeriod(String certificatePeriod) {
        this.certificatePeriod = certificatePeriod;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

}
