package com.beyontec.mol.modal;

import java.util.Set;
import com.beyontec.mol.entity.UserGroup;

public class UserDTO {

    private String userId;

    private String loginId;

    private String firstName;

    private String lastName;

    private String mailId;

    private String mobileNumber;

    private String isFirstLogin;

    private Set<String> userMenu;

    private Set<UserGroup> userGroups;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public Set<String> getUserMenu() {
        return userMenu;
    }

    public void setUserMenu(Set<String> userMenu) {
        this.userMenu = userMenu;
    }

    public Set<UserGroup> getUserGroups() {
        return userGroups;
    }

    public void setUserGroups(Set<UserGroup> userGroups) {
        this.userGroups = userGroups;
    }

    public String getLoginStatus() {
        return isFirstLogin;
    }

    public void setLoginStatus(String isFirstLogin) {
        this.isFirstLogin = isFirstLogin;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }
}
