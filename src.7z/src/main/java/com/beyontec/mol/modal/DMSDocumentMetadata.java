package com.beyontec.mol.modal;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DMSDocumentMetadata {

	@NotBlank
	private String entityRefId;

	@NotBlank
	private String entityRefType;

	private String userId;

	private String companyId;

	private String partyType;

	private String documentType;

	private String description;

	private String fileName;

	private String fileType;

	private String uploadedDateTime;

	private String thumbnail;

	private String content;

	private String contentType;

	private String gridFSId;

	public String getEntityRefId() {
		return entityRefId;
	}

	public void setEntityRefId(String entityRefId) {
		this.entityRefId = entityRefId;
	}

	public String getEntityRefType() {
		return entityRefType;
	}

	public void setEntityRefType(String entityRefType) {
		this.entityRefType = entityRefType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getUploadedDateTime() {
		return uploadedDateTime;
	}

	public void setUploadedDateTime(String uploadedDateTime) {
		this.uploadedDateTime = uploadedDateTime;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getGridFSId() {
		return gridFSId;
	}

	public void setGridFSId(String gridFSId) {
		this.gridFSId = gridFSId;
	}
}
