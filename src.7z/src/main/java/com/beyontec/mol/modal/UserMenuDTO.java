package com.beyontec.mol.modal;

import java.util.HashSet;
import java.util.Set;

import com.beyontec.mol.entity.UserGroup;

    public class UserMenuDTO {

    private String id;

    private String functionId;

    private String name;

    private Set<UserGroup> userGroups = new HashSet<>();

    public String getId() {
            return id;
    }

    public void setId(String id) {
            this.id = id;
    }

    public String getFunctionId() {
        return functionId;
    }

    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<UserGroup> getUserGroups() {
        return userGroups;
    }

    public void setUserGroups(Set<UserGroup> userGroups) {
        this.userGroups = userGroups;
    }
}
