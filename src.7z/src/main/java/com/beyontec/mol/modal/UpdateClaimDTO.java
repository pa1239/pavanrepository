package com.beyontec.mol.modal;

import org.hibernate.validator.constraints.NotBlank;

public class UpdateClaimDTO {

	@NotBlank
	private String complaintNumber;
	
	@NotBlank
	private String workerEmiratesId;
	
	@NotBlank
	private String visaReferenceNo;
	
	private String notes;

	public String getComplaintNumber() {
		return complaintNumber;
	}

	public void setComplaintNumber(String complaintNumber) {
		this.complaintNumber = complaintNumber;
	}

	public String getWorkerEmiratesId() {
		return workerEmiratesId;
	}

	public void setWorkerEmiratesId(String workerEmiratesId) {
		this.workerEmiratesId = workerEmiratesId;
	}

	public String getVisaReferenceNo() {
		return visaReferenceNo;
	}

	public void setVisaReferenceNo(String visaReferenceNo) {
		this.visaReferenceNo = visaReferenceNo;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

}
