package com.beyontec.mol.modal;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(name = "MODEL_TEST")
public class ModelTest {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "myseq")
	@SequenceGenerator(name = "myseq", sequenceName = "MY_SEQ")
	@Column(name = "ID")
	private Long id;

	@Column(name = "NAME")
	private String name;

	@JsonSerialize(using = MyDateSerializer.class)
	@Column(name = "MY_DATE")
	private Date myDate;
	
	

}
