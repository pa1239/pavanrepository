package com.beyontec.mol.modal;

public class SponsorDetails {

    private String sponsorName;
    private String tradeLicenseNo;
    private String estabClassification;
    private String industry;

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public String getTradeLicenseNo() {
        return tradeLicenseNo;
    }

    public void setTradeLicenseNo(String tradeLicenseNo) {
        this.tradeLicenseNo = tradeLicenseNo;
    }

    public String getEstabClassification() {
        return estabClassification;
    }

    public void setEstabClassification(String estabClassification) {
        this.estabClassification = estabClassification;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }
}
