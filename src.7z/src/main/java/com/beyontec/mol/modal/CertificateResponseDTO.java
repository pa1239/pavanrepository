package com.beyontec.mol.modal;

public class CertificateResponseDTO {

	private String certificateNo;
	
	public CertificateResponseDTO(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

}
