package com.beyontec.mol.modal;

import java.util.List;

public class PaymentListingDTO {

	private ClaimDetails claimDetails;
	private List<PaymentEstimateDetails> paymentEstimateDetails;
	private PaymentDetails paymentReview;
	private PaymentDetails paymentApproval;
	public ClaimDetails getClaimDetails() {
		return claimDetails;
	}
	public void setClaimDetails(ClaimDetails claimDetails) {
		this.claimDetails = claimDetails;
	}
	public List<PaymentEstimateDetails> getPaymentEstimateDetails() {
		return paymentEstimateDetails;
	}
	public void setPaymentEstimateDetails(List<PaymentEstimateDetails> paymentEstimateDetails) {
		this.paymentEstimateDetails = paymentEstimateDetails;
	}
	public PaymentDetails getPaymentReview() {
		return paymentReview;
	}
	public void setPaymentReview(PaymentDetails paymentReview) {
		this.paymentReview = paymentReview;
	}
	public PaymentDetails getPaymentApproval() {
		return paymentApproval;
	}
	public void setPaymentApproval(PaymentDetails paymentApproval) {
		this.paymentApproval = paymentApproval;
	}

	

}
