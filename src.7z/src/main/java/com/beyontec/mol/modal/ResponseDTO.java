package com.beyontec.mol.modal;

public class ResponseDTO {

	private Boolean success;

	public ResponseDTO(Boolean success) {
		this.success = success;
	}

	public Boolean getSuccess() {
		return success;
	}

	public void setSuccess(Boolean success) {
		this.success = success;
	}

}
