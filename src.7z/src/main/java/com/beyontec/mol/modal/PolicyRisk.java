package com.beyontec.mol.modal;

import java.util.Date;

public class PolicyRisk {

    private String companyId;
    private String policyNo;
    private String policySgsId;
    private String customerId;
    private String productId;
    private String cobId;
    private Date policyEffectiveFrom;
    private Date policyEffectiveTo;
    private String divisionID;
    private String departmentId;
    private String insuredId;
    private String masterPolicyNo;
    private Date masterPolicyEffectiveFrom;
    private Date masterPolicyEffectiveTo;
    private String reportedDivisionID;
    private String riskId;
    private Date riskEffectiveFrom;
    private Date riskEffectiveTo;
    private String riskType;
    private String flex7;
    private int riskAmendmentVerNo;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getPolicySgsId() {
        return policySgsId;
    }

    public void setPolicySgsId(String policySgsId) {
        this.policySgsId = policySgsId;
    }

    public int getRiskAmendmentVerNo() {
        return riskAmendmentVerNo;
    }

    public void setRiskAmendmentVerNo(int riskAmendmentVerNo) {
        this.riskAmendmentVerNo = riskAmendmentVerNo;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCobId() {
        return cobId;
    }

    public void setCobId(String cobId) {
        this.cobId = cobId;
    }

    public Date getPolicyEffectiveFrom() {
        return policyEffectiveFrom;
    }

    public void setPolicyEffectiveFrom(Date policyEffectiveFrom) {
        this.policyEffectiveFrom = policyEffectiveFrom;
    }

    public Date getPolicyEffectiveTo() {
        return policyEffectiveTo;
    }

    public void setPolicyEffectiveTo(Date policyEffectiveTo) {
        this.policyEffectiveTo = policyEffectiveTo;
    }

    public String getDivisionID() {
        return divisionID;
    }

    public void setDivisionID(String divisionID) {
        this.divisionID = divisionID;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getInsuredId() {
        return insuredId;
    }

    public void setInsuredId(String insuredId) {
        this.insuredId = insuredId;
    }

    public String getMasterPolicyNo() {
        return masterPolicyNo;
    }

    public void setMasterPolicyNo(String masterPolicyNo) {
        this.masterPolicyNo = masterPolicyNo;
    }

    public Date getMasterPolicyEffectiveFrom() {
        return masterPolicyEffectiveFrom;
    }

    public void setMasterPolicyEffectiveFrom(Date masterPolicyEffectiveFrom) {
        this.masterPolicyEffectiveFrom = masterPolicyEffectiveFrom;
    }

    public Date getMasterPolicyEffectiveTo() {
        return masterPolicyEffectiveTo;
    }

    public void setMasterPolicyEffectiveTo(Date masterPolicyEffectiveTo) {
        this.masterPolicyEffectiveTo = masterPolicyEffectiveTo;
    }

    public String getReportedDivisionID() {
        return reportedDivisionID;
    }

    public void setReportedDivisionID(String reportedDivisionID) {
        this.reportedDivisionID = reportedDivisionID;
    }

    public String getRiskId() {
        return riskId;
    }

    public void setRiskId(String riskId) {
        this.riskId = riskId;
    }

    public Date getRiskEffectiveFrom() {
        return riskEffectiveFrom;
    }

    public void setRiskEffectiveFrom(Date riskEffectiveFrom) {
        this.riskEffectiveFrom = riskEffectiveFrom;
    }

    public Date getRiskEffectiveTo() {
        return riskEffectiveTo;
    }

    public void setRiskEffectiveTo(Date riskEffectiveTo) {
        this.riskEffectiveTo = riskEffectiveTo;
    }

    public String getRiskType() {
        return riskType;
    }

    public void setRiskType(String riskType) {
        this.riskType = riskType;
    }

    public String getFlex7() {
        return flex7;
    }

    public void setFlex7(String flex7) {
        this.flex7 = flex7;
    }

	@Override
	public String toString() {
		return "PolicyRisk [companyId=" + companyId + ", policyNo=" + policyNo + ", policySgsId=" + policySgsId
				+ ", customerId=" + customerId + ", productId=" + productId + ", cobId=" + cobId
				+ ", policyEffectiveFrom=" + policyEffectiveFrom + ", policyEffectiveTo=" + policyEffectiveTo
				+ ", divisionID=" + divisionID + ", departmentId=" + departmentId + ", insuredId=" + insuredId
				+ ", masterPolicyNo=" + masterPolicyNo + ", masterPolicyEffectiveFrom=" + masterPolicyEffectiveFrom
				+ ", masterPolicyEffectiveTo=" + masterPolicyEffectiveTo + ", reportedDivisionID=" + reportedDivisionID
				+ ", riskId=" + riskId + ", riskEffectiveFrom=" + riskEffectiveFrom + ", riskEffectiveTo="
				+ riskEffectiveTo + ", riskType=" + riskType + ", flex7=" + flex7 + ", riskAmendmentVerNo="
				+ riskAmendmentVerNo + "]";
	}
    
}
