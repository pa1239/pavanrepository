package com.beyontec.mol.modal;

import java.util.List;

public class PagedResult<T> extends BaseModal {

    private static final long serialVersionUID = -5812192792998675773L;

    private List<T> records;
    private Long total;

    public PagedResult(List<T> records, Long total) {
        this.records = records;
        this.total = total;
    }

    public List<T> getRecords() {
        return records;
    }

    public void setRecords(List<T> records) {
        this.records = records;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }
}
