package com.beyontec.mol.modal;

import java.util.List;

public class ClaimResponse {

    private long count;
    private List<ClaimDTO> claims;

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public List<ClaimDTO> getClaims() {
        return claims;
    }

    public void setClaims(List<ClaimDTO> claims) {
        this.claims = claims;
    }

}
