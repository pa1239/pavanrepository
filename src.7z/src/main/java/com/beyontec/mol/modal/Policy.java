package com.beyontec.mol.modal;

public class Policy {

	private String ULM_TYP;
	private String ULM_NO;
	private String ULM_LVL1_NO;
	private String ULM_LVL1_ITR_NO;
	private String ULM_COMP_ID;
	private String ULM_DIVN_ID;
	private String ULM_DEPT_ID;
	//private String ULM_PROD_ID;
	private String ULM_ISSUE_DATE;
	private String ULM_FMD;
	private String ULM_TOD;
	private String ULM_PERIOD_UNIT;
	private String ULM_PERIOD;
	private String ULM_PREM_CALC_TYP;
	private String ULM_BSRC_ID;
	private String ULM_BTYP_ID;
	private String ULM_STATUS;
	private String ULM_AMND_NO;
	private String ULM_AMND_VER_NO;
	private String ULM_CUST_ID;
	private String ULM_ADDR_REF_ID;
	private String ULM_CONT_REF_ID;
	private String ULM_INSRD_ID;
	private String ULM_INSRD_NAME;
	private String ULM_REC_TYP;
	private String ULM_CUST_ACC_ID;
	private String ULM_SGS_ID;
	private String ULM_ITR_NO;
	private String ULM_ITR_VER_NO;
	private String ULM_PERIOD_TYP;
	private String ULM_PAYOR_ID;
	private String ULM_PAYOR_ADDR_REF_ID;
	private String ULM_BILL_TYP;
	private String ULM_UI_INST_ID;
	private String ULM_PAYOR_TYP;
	private String ULM_TERM;
	private String ULM_CRU;
	private String ULM_CRD;
	private String ULM_PRIORITY;
	private String ULM_DUE_ON;
	private String ULM_AMND_TYP;
	private String ULM_AMND_SUB_TYP;
	private String ULM_AMND_FMD;
	private String ULM_AMND_TOD;
	private String ULM_CUST_TYP;
	private String ULM_REN_SEQ_NO;
	private String ULM_FLT_YN;
	private String ULM_OSE_YN;
	private String ULM_PRM_CURR;
	private String ULM_PRM_CURR_ID;
	private String ULM_PRM_CURR_X_RATE;
	//private String ULM_MST_REF_NO;
	private String ULM_MST_REF_SGS_ID;
	private String ULM_MST_REF_AMND_VER_NO;
	private String ULM_TMPL_TYP;
	private String ULM_TMPL_ID;
	private String ULM_EQ_TYP;
	//private String ULM_CNAME;
	private String ULM_CADDR_1;
	private String ULM_CADDR_2;
	private String ULM_CADDR_3;
	private String ULM_CADDR_4;
	private String ULM_CPIN_CODE;
	private String ULM_CCITY;
	private String ULM_CSTATE;
	private String ULM_CCOUNTRY;
	private String ULM_CFIRST_NAME;
	private String ULM_CMIDDLE_NAME;
	private String ULM_CLAST_NAME;
	private String ULM_PREFIX_NAME;
	private String ULM_PREFIX_NAME_BL;
	private String ULM_CNAME_BL;
	private String ULM_CFIRST_NAME_BL;
	private String ULM_CLAST_NAME_BL;
	private String ULM_CPY_PHONE_NO;
	private String ULM_CPY_MOBILE_NO;
	private String ULM_CFAX_NO;
	private String ULM_CPY_EMAIL_ID;
	private String ULM_REN_POL_NO;
	private String ULM_SI_CURR;
	private String ULM_SI_CURR_ID;
	private String ULM_SI_X_RATE;

	private String selectPolicyType;
	private String masterPolicyNo;
	private String customerName;
	private String productType;

	public String getULM_TYP() {
		return ULM_TYP;
	}

	public void setULM_TYP(String uLM_TYP) {
		ULM_TYP = uLM_TYP;
	}

	public String getULM_NO() {
		return ULM_NO;
	}

	public void setULM_NO(String uLM_NO) {
		ULM_NO = uLM_NO;
	}

	public String getULM_LVL1_NO() {
		return ULM_LVL1_NO;
	}

	public void setULM_LVL1_NO(String uLM_LVL1_NO) {
		ULM_LVL1_NO = uLM_LVL1_NO;
	}

	public String getULM_LVL1_ITR_NO() {
		return ULM_LVL1_ITR_NO;
	}

	public void setULM_LVL1_ITR_NO(String uLM_LVL1_ITR_NO) {
		ULM_LVL1_ITR_NO = uLM_LVL1_ITR_NO;
	}

	public String getULM_COMP_ID() {
		return ULM_COMP_ID;
	}

	public void setULM_COMP_ID(String uLM_COMP_ID) {
		ULM_COMP_ID = uLM_COMP_ID;
	}

	public String getULM_DIVN_ID() {
		return ULM_DIVN_ID;
	}

	public void setULM_DIVN_ID(String uLM_DIVN_ID) {
		ULM_DIVN_ID = uLM_DIVN_ID;
	}

	public String getULM_DEPT_ID() {
		return ULM_DEPT_ID;
	}

	public void setULM_DEPT_ID(String uLM_DEPT_ID) {
		ULM_DEPT_ID = uLM_DEPT_ID;
	}

/*	public String getULM_PROD_ID() {
		return ULM_PROD_ID;
	}

	public void setULM_PROD_ID(String uLM_PROD_ID) {
		ULM_PROD_ID = uLM_PROD_ID;
	}*/

	public String getULM_ISSUE_DATE() {
		return ULM_ISSUE_DATE;
	}

	public void setULM_ISSUE_DATE(String uLM_ISSUE_DATE) {
		ULM_ISSUE_DATE = uLM_ISSUE_DATE;
	}

	public String getULM_FMD() {
		return ULM_FMD;
	}

	public void setULM_FMD(String uLM_FMD) {
		ULM_FMD = uLM_FMD;
	}

	public String getULM_TOD() {
		return ULM_TOD;
	}

	public void setULM_TOD(String uLM_TOD) {
		ULM_TOD = uLM_TOD;
	}

	public String getULM_PERIOD_UNIT() {
		return ULM_PERIOD_UNIT;
	}

	public void setULM_PERIOD_UNIT(String uLM_PERIOD_UNIT) {
		ULM_PERIOD_UNIT = uLM_PERIOD_UNIT;
	}

	public String getULM_PERIOD() {
		return ULM_PERIOD;
	}

	public void setULM_PERIOD(String uLM_PERIOD) {
		ULM_PERIOD = uLM_PERIOD;
	}

	public String getULM_PREM_CALC_TYP() {
		return ULM_PREM_CALC_TYP;
	}

	public void setULM_PREM_CALC_TYP(String uLM_PREM_CALC_TYP) {
		ULM_PREM_CALC_TYP = uLM_PREM_CALC_TYP;
	}

	public String getULM_BSRC_ID() {
		return ULM_BSRC_ID;
	}

	public void setULM_BSRC_ID(String uLM_BSRC_ID) {
		ULM_BSRC_ID = uLM_BSRC_ID;
	}

	public String getULM_BTYP_ID() {
		return ULM_BTYP_ID;
	}

	public void setULM_BTYP_ID(String uLM_BTYP_ID) {
		ULM_BTYP_ID = uLM_BTYP_ID;
	}

	public String getULM_STATUS() {
		return ULM_STATUS;
	}

	public void setULM_STATUS(String uLM_STATUS) {
		ULM_STATUS = uLM_STATUS;
	}

	public String getULM_AMND_NO() {
		return ULM_AMND_NO;
	}

	public void setULM_AMND_NO(String uLM_AMND_NO) {
		ULM_AMND_NO = uLM_AMND_NO;
	}

	public String getULM_AMND_VER_NO() {
		return ULM_AMND_VER_NO;
	}

	public void setULM_AMND_VER_NO(String uLM_AMND_VER_NO) {
		ULM_AMND_VER_NO = uLM_AMND_VER_NO;
	}

	public String getULM_CUST_ID() {
		return ULM_CUST_ID;
	}

	public void setULM_CUST_ID(String uLM_CUST_ID) {
		ULM_CUST_ID = uLM_CUST_ID;
	}

	public String getULM_ADDR_REF_ID() {
		return ULM_ADDR_REF_ID;
	}

	public void setULM_ADDR_REF_ID(String uLM_ADDR_REF_ID) {
		ULM_ADDR_REF_ID = uLM_ADDR_REF_ID;
	}

	public String getULM_CONT_REF_ID() {
		return ULM_CONT_REF_ID;
	}

	public void setULM_CONT_REF_ID(String uLM_CONT_REF_ID) {
		ULM_CONT_REF_ID = uLM_CONT_REF_ID;
	}

	public String getULM_INSRD_ID() {
		return ULM_INSRD_ID;
	}

	public void setULM_INSRD_ID(String uLM_INSRD_ID) {
		ULM_INSRD_ID = uLM_INSRD_ID;
	}

	public String getULM_INSRD_NAME() {
		return ULM_INSRD_NAME;
	}

	public void setULM_INSRD_NAME(String uLM_INSRD_NAME) {
		ULM_INSRD_NAME = uLM_INSRD_NAME;
	}

	public String getULM_REC_TYP() {
		return ULM_REC_TYP;
	}

	public void setULM_REC_TYP(String uLM_REC_TYP) {
		ULM_REC_TYP = uLM_REC_TYP;
	}

	public String getULM_CUST_ACC_ID() {
		return ULM_CUST_ACC_ID;
	}

	public void setULM_CUST_ACC_ID(String uLM_CUST_ACC_ID) {
		ULM_CUST_ACC_ID = uLM_CUST_ACC_ID;
	}

	public String getULM_SGS_ID() {
		return ULM_SGS_ID;
	}

	public void setULM_SGS_ID(String uLM_SGS_ID) {
		ULM_SGS_ID = uLM_SGS_ID;
	}

	public String getULM_ITR_NO() {
		return ULM_ITR_NO;
	}

	public void setULM_ITR_NO(String uLM_ITR_NO) {
		ULM_ITR_NO = uLM_ITR_NO;
	}

	public String getULM_ITR_VER_NO() {
		return ULM_ITR_VER_NO;
	}

	public void setULM_ITR_VER_NO(String uLM_ITR_VER_NO) {
		ULM_ITR_VER_NO = uLM_ITR_VER_NO;
	}

	public String getULM_PERIOD_TYP() {
		return ULM_PERIOD_TYP;
	}

	public void setULM_PERIOD_TYP(String uLM_PERIOD_TYP) {
		ULM_PERIOD_TYP = uLM_PERIOD_TYP;
	}

	public String getULM_PAYOR_ID() {
		return ULM_PAYOR_ID;
	}

	public void setULM_PAYOR_ID(String uLM_PAYOR_ID) {
		ULM_PAYOR_ID = uLM_PAYOR_ID;
	}

	public String getULM_PAYOR_ADDR_REF_ID() {
		return ULM_PAYOR_ADDR_REF_ID;
	}

	public void setULM_PAYOR_ADDR_REF_ID(String uLM_PAYOR_ADDR_REF_ID) {
		ULM_PAYOR_ADDR_REF_ID = uLM_PAYOR_ADDR_REF_ID;
	}

	public String getULM_BILL_TYP() {
		return ULM_BILL_TYP;
	}

	public void setULM_BILL_TYP(String uLM_BILL_TYP) {
		ULM_BILL_TYP = uLM_BILL_TYP;
	}

	public String getULM_UI_INST_ID() {
		return ULM_UI_INST_ID;
	}

	public void setULM_UI_INST_ID(String uLM_UI_INST_ID) {
		ULM_UI_INST_ID = uLM_UI_INST_ID;
	}

	public String getULM_PAYOR_TYP() {
		return ULM_PAYOR_TYP;
	}

	public void setULM_PAYOR_TYP(String uLM_PAYOR_TYP) {
		ULM_PAYOR_TYP = uLM_PAYOR_TYP;
	}

	public String getULM_TERM() {
		return ULM_TERM;
	}

	public void setULM_TERM(String uLM_TERM) {
		ULM_TERM = uLM_TERM;
	}

	public String getULM_CRU() {
		return ULM_CRU;
	}

	public void setULM_CRU(String uLM_CRU) {
		ULM_CRU = uLM_CRU;
	}

	public String getULM_CRD() {
		return ULM_CRD;
	}

	public void setULM_CRD(String uLM_CRD) {
		ULM_CRD = uLM_CRD;
	}

	public String getULM_PRIORITY() {
		return ULM_PRIORITY;
	}

	public void setULM_PRIORITY(String uLM_PRIORITY) {
		ULM_PRIORITY = uLM_PRIORITY;
	}

	public String getULM_DUE_ON() {
		return ULM_DUE_ON;
	}

	public void setULM_DUE_ON(String uLM_DUE_ON) {
		ULM_DUE_ON = uLM_DUE_ON;
	}

	public String getULM_AMND_TYP() {
		return ULM_AMND_TYP;
	}

	public void setULM_AMND_TYP(String uLM_AMND_TYP) {
		ULM_AMND_TYP = uLM_AMND_TYP;
	}

	public String getULM_AMND_SUB_TYP() {
		return ULM_AMND_SUB_TYP;
	}

	public void setULM_AMND_SUB_TYP(String uLM_AMND_SUB_TYP) {
		ULM_AMND_SUB_TYP = uLM_AMND_SUB_TYP;
	}

	public String getULM_AMND_FMD() {
		return ULM_AMND_FMD;
	}

	public void setULM_AMND_FMD(String uLM_AMND_FMD) {
		ULM_AMND_FMD = uLM_AMND_FMD;
	}

	public String getULM_AMND_TOD() {
		return ULM_AMND_TOD;
	}

	public void setULM_AMND_TOD(String uLM_AMND_TOD) {
		ULM_AMND_TOD = uLM_AMND_TOD;
	}

	public String getULM_CUST_TYP() {
		return ULM_CUST_TYP;
	}

	public void setULM_CUST_TYP(String uLM_CUST_TYP) {
		ULM_CUST_TYP = uLM_CUST_TYP;
	}

	public String getULM_REN_SEQ_NO() {
		return ULM_REN_SEQ_NO;
	}

	public void setULM_REN_SEQ_NO(String uLM_REN_SEQ_NO) {
		ULM_REN_SEQ_NO = uLM_REN_SEQ_NO;
	}

	public String getULM_FLT_YN() {
		return ULM_FLT_YN;
	}

	public void setULM_FLT_YN(String uLM_FLT_YN) {
		ULM_FLT_YN = uLM_FLT_YN;
	}

	public String getULM_OSE_YN() {
		return ULM_OSE_YN;
	}

	public void setULM_OSE_YN(String uLM_OSE_YN) {
		ULM_OSE_YN = uLM_OSE_YN;
	}

	public String getULM_PRM_CURR() {
		return ULM_PRM_CURR;
	}

	public void setULM_PRM_CURR(String uLM_PRM_CURR) {
		ULM_PRM_CURR = uLM_PRM_CURR;
	}

	public String getULM_PRM_CURR_ID() {
		return ULM_PRM_CURR_ID;
	}

	public void setULM_PRM_CURR_ID(String uLM_PRM_CURR_ID) {
		ULM_PRM_CURR_ID = uLM_PRM_CURR_ID;
	}

	public String getULM_PRM_CURR_X_RATE() {
		return ULM_PRM_CURR_X_RATE;
	}

	public void setULM_PRM_CURR_X_RATE(String uLM_PRM_CURR_X_RATE) {
		ULM_PRM_CURR_X_RATE = uLM_PRM_CURR_X_RATE;
	}

	/*public String getULM_MST_REF_NO() {
		return ULM_MST_REF_NO;
	}

	public void setULM_MST_REF_NO(String uLM_MST_REF_NO) {
		ULM_MST_REF_NO = uLM_MST_REF_NO;
	}
*/
	public String getULM_MST_REF_SGS_ID() {
		return ULM_MST_REF_SGS_ID;
	}

	public void setULM_MST_REF_SGS_ID(String uLM_MST_REF_SGS_ID) {
		ULM_MST_REF_SGS_ID = uLM_MST_REF_SGS_ID;
	}

	public String getULM_MST_REF_AMND_VER_NO() {
		return ULM_MST_REF_AMND_VER_NO;
	}

	public void setULM_MST_REF_AMND_VER_NO(String uLM_MST_REF_AMND_VER_NO) {
		ULM_MST_REF_AMND_VER_NO = uLM_MST_REF_AMND_VER_NO;
	}

	public String getULM_TMPL_TYP() {
		return ULM_TMPL_TYP;
	}

	public void setULM_TMPL_TYP(String uLM_TMPL_TYP) {
		ULM_TMPL_TYP = uLM_TMPL_TYP;
	}

	public String getULM_TMPL_ID() {
		return ULM_TMPL_ID;
	}

	public void setULM_TMPL_ID(String uLM_TMPL_ID) {
		ULM_TMPL_ID = uLM_TMPL_ID;
	}

	public String getULM_EQ_TYP() {
		return ULM_EQ_TYP;
	}

	public void setULM_EQ_TYP(String uLM_EQ_TYP) {
		ULM_EQ_TYP = uLM_EQ_TYP;
	}

/*	public String getULM_CNAME() {
		return ULM_CNAME;
	}

	public void setULM_CNAME(String uLM_CNAME) {
		ULM_CNAME = uLM_CNAME;
	}*/

	public String getULM_CADDR_1() {
		return ULM_CADDR_1;
	}

	public void setULM_CADDR_1(String uLM_CADDR_1) {
		ULM_CADDR_1 = uLM_CADDR_1;
	}

	public String getULM_CADDR_2() {
		return ULM_CADDR_2;
	}

	public void setULM_CADDR_2(String uLM_CADDR_2) {
		ULM_CADDR_2 = uLM_CADDR_2;
	}

	public String getULM_CADDR_3() {
		return ULM_CADDR_3;
	}

	public void setULM_CADDR_3(String uLM_CADDR_3) {
		ULM_CADDR_3 = uLM_CADDR_3;
	}

	public String getULM_CADDR_4() {
		return ULM_CADDR_4;
	}

	public void setULM_CADDR_4(String uLM_CADDR_4) {
		ULM_CADDR_4 = uLM_CADDR_4;
	}

	public String getULM_CPIN_CODE() {
		return ULM_CPIN_CODE;
	}

	public void setULM_CPIN_CODE(String uLM_CPIN_CODE) {
		ULM_CPIN_CODE = uLM_CPIN_CODE;
	}

	public String getULM_CCITY() {
		return ULM_CCITY;
	}

	public void setULM_CCITY(String uLM_CCITY) {
		ULM_CCITY = uLM_CCITY;
	}

	public String getULM_CSTATE() {
		return ULM_CSTATE;
	}

	public void setULM_CSTATE(String uLM_CSTATE) {
		ULM_CSTATE = uLM_CSTATE;
	}

	public String getULM_CCOUNTRY() {
		return ULM_CCOUNTRY;
	}

	public void setULM_CCOUNTRY(String uLM_CCOUNTRY) {
		ULM_CCOUNTRY = uLM_CCOUNTRY;
	}

	public String getULM_CFIRST_NAME() {
		return ULM_CFIRST_NAME;
	}

	public void setULM_CFIRST_NAME(String uLM_CFIRST_NAME) {
		ULM_CFIRST_NAME = uLM_CFIRST_NAME;
	}

	public String getULM_CMIDDLE_NAME() {
		return ULM_CMIDDLE_NAME;
	}

	public void setULM_CMIDDLE_NAME(String uLM_CMIDDLE_NAME) {
		ULM_CMIDDLE_NAME = uLM_CMIDDLE_NAME;
	}

	public String getULM_CLAST_NAME() {
		return ULM_CLAST_NAME;
	}

	public void setULM_CLAST_NAME(String uLM_CLAST_NAME) {
		ULM_CLAST_NAME = uLM_CLAST_NAME;
	}

	public String getULM_PREFIX_NAME() {
		return ULM_PREFIX_NAME;
	}

	public void setULM_PREFIX_NAME(String uLM_PREFIX_NAME) {
		ULM_PREFIX_NAME = uLM_PREFIX_NAME;
	}

	public String getULM_PREFIX_NAME_BL() {
		return ULM_PREFIX_NAME_BL;
	}

	public void setULM_PREFIX_NAME_BL(String uLM_PREFIX_NAME_BL) {
		ULM_PREFIX_NAME_BL = uLM_PREFIX_NAME_BL;
	}

	public String getULM_CNAME_BL() {
		return ULM_CNAME_BL;
	}

	public void setULM_CNAME_BL(String uLM_CNAME_BL) {
		ULM_CNAME_BL = uLM_CNAME_BL;
	}

	public String getULM_CFIRST_NAME_BL() {
		return ULM_CFIRST_NAME_BL;
	}

	public void setULM_CFIRST_NAME_BL(String uLM_CFIRST_NAME_BL) {
		ULM_CFIRST_NAME_BL = uLM_CFIRST_NAME_BL;
	}

	public String getULM_CLAST_NAME_BL() {
		return ULM_CLAST_NAME_BL;
	}

	public void setULM_CLAST_NAME_BL(String uLM_CLAST_NAME_BL) {
		ULM_CLAST_NAME_BL = uLM_CLAST_NAME_BL;
	}

	public String getULM_CPY_PHONE_NO() {
		return ULM_CPY_PHONE_NO;
	}

	public void setULM_CPY_PHONE_NO(String uLM_CPY_PHONE_NO) {
		ULM_CPY_PHONE_NO = uLM_CPY_PHONE_NO;
	}

	public String getULM_CPY_MOBILE_NO() {
		return ULM_CPY_MOBILE_NO;
	}

	public void setULM_CPY_MOBILE_NO(String uLM_CPY_MOBILE_NO) {
		ULM_CPY_MOBILE_NO = uLM_CPY_MOBILE_NO;
	}

	public String getULM_CFAX_NO() {
		return ULM_CFAX_NO;
	}

	public void setULM_CFAX_NO(String uLM_CFAX_NO) {
		ULM_CFAX_NO = uLM_CFAX_NO;
	}

	public String getULM_CPY_EMAIL_ID() {
		return ULM_CPY_EMAIL_ID;
	}

	public void setULM_CPY_EMAIL_ID(String uLM_CPY_EMAIL_ID) {
		ULM_CPY_EMAIL_ID = uLM_CPY_EMAIL_ID;
	}

	public String getULM_REN_POL_NO() {
		return ULM_REN_POL_NO;
	}

	public void setULM_REN_POL_NO(String uLM_REN_POL_NO) {
		ULM_REN_POL_NO = uLM_REN_POL_NO;
	}

	public String getULM_SI_CURR() {
		return ULM_SI_CURR;
	}

	public void setULM_SI_CURR(String uLM_SI_CURR) {
		ULM_SI_CURR = uLM_SI_CURR;
	}

	public String getULM_SI_CURR_ID() {
		return ULM_SI_CURR_ID;
	}

	public void setULM_SI_CURR_ID(String uLM_SI_CURR_ID) {
		ULM_SI_CURR_ID = uLM_SI_CURR_ID;
	}

	public String getULM_SI_X_RATE() {
		return ULM_SI_X_RATE;
	}

	public void setULM_SI_X_RATE(String uLM_SI_X_RATE) {
		ULM_SI_X_RATE = uLM_SI_X_RATE;
	}

	public String getSelectPolicyType() {
		return selectPolicyType;
	}

	public void setSelectPolicyType(String selectPolicyType) {
		this.selectPolicyType = selectPolicyType;
	}

	public String getMasterPolicyNo() {
		return masterPolicyNo;
	}

	public void setMasterPolicyNo(String masterPolicyNo) {
		this.masterPolicyNo = masterPolicyNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

}
