package com.beyontec.mol.modal;

import java.io.Serializable;

public abstract class BaseModal implements Serializable {

    private static final long serialVersionUID = 7632106681959344094L;

    @Override
    public String toString() {
        return super.toString();
    }
}
