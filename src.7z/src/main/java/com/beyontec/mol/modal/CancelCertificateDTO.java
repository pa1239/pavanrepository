package com.beyontec.mol.modal;

import java.util.Date;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CancelCertificateDTO {

	@NotBlank
	private String cancelType;

	@NotBlank
	private String certificateNo;

	@JsonFormat(pattern = "dd-MM-yyyy")
	private Date cancelledDate;

	@NotBlank
	private String cancelReason;

	@NotBlank
	private String labourReferenceNo;

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	public Date getCancelledDate() {
		return cancelledDate;
	}

	public void setCancelledDate(Date cancelledDate) {
		this.cancelledDate = cancelledDate;
	}

	public String getCancelType() {
		return cancelType;
	}

	public void setCancelType(String cancelType) {
		this.cancelType = cancelType;
	}

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	public String getLabourReferenceNo() {
		return labourReferenceNo;
	}

	public void setLabourReferenceNo(String labourReferenceNo) {
		this.labourReferenceNo = labourReferenceNo;
	}

}
