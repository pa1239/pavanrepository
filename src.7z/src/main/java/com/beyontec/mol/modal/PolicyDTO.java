package com.beyontec.mol.modal;

import java.util.List;

public class PolicyDTO {

	private List<Policy> policyList;
	private int count;

	public List<Policy> getPolicyList() {
		return policyList;
	}

	public void setPolicyList(List<Policy> policyList) {
		this.policyList = policyList;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public PolicyDTO(List<Policy> policyList, int count) {
		this.policyList = policyList;
		this.count = count;

	}

}
