package com.beyontec.mol.modal;

public class Password {

    private String loginId;

    private String oldPassword;

    private String newPassword;

    public String getLoginId() {
        return loginId;
    }

    public void setloginId(String loginId) {
        this.loginId = loginId;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}
