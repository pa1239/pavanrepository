package com.beyontec.mol.modal;

public class PolicySearchCriteria {

	private String selectPolicyType;
	private String masterPolicyNo;
	private String customerName;
	private String productType;

	private String offSet;

	public String getSelectPolicyType() {
		return selectPolicyType;
	}

	public void setSelectPolicyType(String selectPolicyType) {
		this.selectPolicyType = selectPolicyType;
	}

	public String getMasterPolicyNo() {
		return masterPolicyNo;
	}

	public void setMasterPolicyNo(String masterPolicyNo) {
		this.masterPolicyNo = masterPolicyNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getOffSet() {
		return offSet;
	}

	public void setOffSet(String offSet) {
		this.offSet = offSet;
	}

}
